package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.WorldFolderManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(SelectWorldScreen.class)
public abstract class SelectWorldScreenMixin extends Screen {

    @Final
    @Shadow
    protected Screen parent;

    protected SelectWorldScreenMixin() {
        super(Text.empty());
    }

    // Verhindert automatisches Öffnen des Create-World-Dialogs bei leerer Weltliste.
    // require = 0: kein Crash wenn Vanilla diesen setScreen-Aufruf nicht hat.
    @Redirect(method = "init", require = 0, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;setScreen(Lnet/minecraft/client/gui/screen/Screen;)V"))
    private void preventAutoCreateWorld(MinecraftClient client, Screen screen) {
        if (!(screen instanceof CreateWorldScreen)) {
            client.setScreen(screen);
        }
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void addDownloadedWorldsButton(CallbackInfo ci) {
        boolean active = WorldFolderManager.isDownloadedWorldsActive();
        boolean hasDownloaded = WorldFolderManager.hasDownloadedWorlds(this.client);

        // Button ausblenden wenn downloaded_worlds/ nie existiert hat und wir nicht dort sind
        if (!active && !hasDownloaded) {
            return;
        }

        Text label = active
                ? Text.translatable("worlddownloader.gui.normal_worlds")
                : Text.translatable("worlddownloader.gui.downloaded_worlds");

        ButtonWidget button = ButtonWidget.builder(label, btn -> {
            WorldFolderManager.toggle(this.client);
            this.client.setScreen(new SelectWorldScreen(this.parent));
        }).dimensions(this.width / 2 + 156, this.height - 52, 150, 20).build();

        // Button deaktivieren wenn downloaded_worlds/ leer ist und man wechseln würde
        if (!active && !hasDownloaded) {
            button.active = false;
        }

        this.addDrawableChild(button);
    }
}
