package net.kuudraloremaster.worlddownloader.screen;

import net.kuudraloremaster.worlddownloader.config.ModConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Settings screen for World Downloader with modern two-column layout.
 * Left: Category list (General, Export)
 * Right: Settings with ON/OFF toggles and descriptions
 */
public class ModSettingsScreen extends Screen {

    private final Screen parent;
    private Category currentCategory = Category.GENERAL;

    // Category buttons
    private ButtonWidget generalButton;
    private ButtonWidget exportButton;

    // General settings
    private ButtonWidget autoRecordButton;
    private ButtonWidget autoExportButton;
    private ButtonWidget autoExportOnDisconnectButton;
    private ButtonWidget autoExportSingleplayerButton;

    // Export settings
    private ButtonWidget exportWithTexturePackButton;
    private ButtonWidget saveContainersButton;

    // Common buttons
    private ButtonWidget resetButton;
    private ButtonWidget doneButton;

    public ModSettingsScreen(Screen parent) {
        super(Text.translatable("worlddownloader.config.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        int leftPanelWidth = 150;
        int leftX = 20;
        int rightX = leftX + leftPanelWidth + 20;
        int rightPanelWidth = width - rightX - 20;
        int buttonHeight = 20;
        int spacing = 8;

        // === LEFT PANEL - Categories ===
        int categoryY = 30;
        generalButton = ButtonWidget.builder(
            Text.translatable("worlddownloader.config.category.general"),
            b -> switchCategory(Category.GENERAL)
        ).dimensions(leftX, categoryY, leftPanelWidth, buttonHeight).build();

        exportButton = ButtonWidget.builder(
            Text.translatable("worlddownloader.config.category.export"),
            b -> switchCategory(Category.EXPORT)
        ).dimensions(leftX, categoryY + buttonHeight + spacing, leftPanelWidth, buttonHeight).build();

        addDrawableChild(generalButton);
        addDrawableChild(exportButton);

        // === RIGHT PANEL - Settings ===
        int settingStartY = 30;
        int settingButtonWidth = rightPanelWidth;

        // General settings
        autoRecordButton = ButtonWidget.builder(
            getToggleText("worlddownloader.config.autoRecord", ModConfig.getInstance().isAutoRecord()),
            b -> toggleAutoRecord()
        ).dimensions(rightX, settingStartY, settingButtonWidth, buttonHeight).build();

        autoExportButton = ButtonWidget.builder(
            getToggleText("worlddownloader.config.autoExport", ModConfig.getInstance().isAutoExport()),
            b -> toggleAutoExport()
        ).dimensions(rightX, settingStartY + (buttonHeight + spacing) * 1, settingButtonWidth, buttonHeight).build();

        autoExportOnDisconnectButton = ButtonWidget.builder(
            getToggleText("worlddownloader.config.autoExportOnDisconnect", ModConfig.getInstance().isAutoExportOnDisconnect()),
            b -> toggleAutoExportOnDisconnect()
        ).dimensions(rightX, settingStartY + (buttonHeight + spacing) * 2, settingButtonWidth, buttonHeight).build();

        autoExportSingleplayerButton = ButtonWidget.builder(
            getToggleText("worlddownloader.config.autoExportSingleplayer", ModConfig.getInstance().isAutoExportSingleplayer()),
            b -> toggleAutoExportSingleplayer()
        ).dimensions(rightX, settingStartY + (buttonHeight + spacing) * 3, settingButtonWidth, buttonHeight).build();

        // Export settings
        exportWithTexturePackButton = ButtonWidget.builder(
            getToggleText("worlddownloader.config.exportWithTexturePack", ModConfig.getInstance().isExportWithTexturePack()),
            b -> toggleExportWithTexturePack()
        ).dimensions(rightX, settingStartY, settingButtonWidth, buttonHeight).build();

        saveContainersButton = ButtonWidget.builder(
            getToggleText("worlddownloader.config.saveContainers", ModConfig.getInstance().isSaveContainers()),
            b -> toggleSaveContainers()
        ).dimensions(rightX, settingStartY + (buttonHeight + spacing) * 1, settingButtonWidth, buttonHeight).build();

        // Reset button (bottom left)
        resetButton = ButtonWidget.builder(
            Text.translatable("worlddownloader.config.reset"),
            b -> resetToDefaults()
        ).dimensions(leftX, height - 50, leftPanelWidth, buttonHeight).build();

        // Done button (bottom center)
        doneButton = ButtonWidget.builder(
            Text.translatable("worlddownloader.config.done"),
            b -> close()
        ).dimensions(width / 2 - 100, height - 30, 200, buttonHeight).build();

        addDrawableChild(resetButton);
        addDrawableChild(doneButton);

        updateCategoryVisibility();
        updateCategoryButtons();
    }

    private void switchCategory(Category category) {
        currentCategory = category;
        updateCategoryVisibility();
        updateCategoryButtons();
    }

    private void updateCategoryButtons() {
        // Highlight selected category
        generalButton.setMessage(Text.translatable("worlddownloader.config.category.general")
            .copy().formatted(currentCategory == Category.GENERAL ? Formatting.WHITE : Formatting.GRAY));
        exportButton.setMessage(Text.translatable("worlddownloader.config.category.export")
            .copy().formatted(currentCategory == Category.EXPORT ? Formatting.WHITE : Formatting.GRAY));
    }

    private Text getToggleText(String translationKey, boolean value) {
        Text name = Text.translatable(translationKey);
        Text status = Text.translatable(value ? "worlddownloader.config.on" : "worlddownloader.config.off")
            .formatted(value ? Formatting.GREEN : Formatting.RED);
        return name.copy().append(Text.literal(": ")).append(status);
    }

    private void toggleAutoRecord() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoRecord(!config.isAutoRecord());
        autoRecordButton.setMessage(getToggleText("worlddownloader.config.autoRecord", config.isAutoRecord()));
    }

    private void toggleAutoExport() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoExport(!config.isAutoExport());
        autoExportButton.setMessage(getToggleText("worlddownloader.config.autoExport", config.isAutoExport()));
    }

    private void toggleAutoExportOnDisconnect() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoExportOnDisconnect(!config.isAutoExportOnDisconnect());
        autoExportOnDisconnectButton.setMessage(getToggleText("worlddownloader.config.autoExportOnDisconnect", config.isAutoExportOnDisconnect()));
    }

    private void toggleAutoExportSingleplayer() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoExportSingleplayer(!config.isAutoExportSingleplayer());
        autoExportSingleplayerButton.setMessage(getToggleText("worlddownloader.config.autoExportSingleplayer", config.isAutoExportSingleplayer()));
    }

    private void toggleExportWithTexturePack() {
        ModConfig config = ModConfig.getInstance();
        config.setExportWithTexturePack(!config.isExportWithTexturePack());
        exportWithTexturePackButton.setMessage(getToggleText("worlddownloader.config.exportWithTexturePack", config.isExportWithTexturePack()));
    }

    private void toggleSaveContainers() {
        ModConfig config = ModConfig.getInstance();
        config.setSaveContainers(!config.isSaveContainers());
        saveContainersButton.setMessage(getToggleText("worlddownloader.config.saveContainers", config.isSaveContainers()));
    }

    private void resetToDefaults() {
        ModConfig.getInstance().resetToDefaults();
        autoRecordButton.setMessage(getToggleText("worlddownloader.config.autoRecord", ModConfig.getInstance().isAutoRecord()));
        autoExportButton.setMessage(getToggleText("worlddownloader.config.autoExport", ModConfig.getInstance().isAutoExport()));
        autoExportOnDisconnectButton.setMessage(getToggleText("worlddownloader.config.autoExportOnDisconnect", ModConfig.getInstance().isAutoExportOnDisconnect()));
        autoExportSingleplayerButton.setMessage(getToggleText("worlddownloader.config.autoExportSingleplayer", ModConfig.getInstance().isAutoExportSingleplayer()));
        exportWithTexturePackButton.setMessage(getToggleText("worlddownloader.config.exportWithTexturePack", ModConfig.getInstance().isExportWithTexturePack()));
        saveContainersButton.setMessage(getToggleText("worlddownloader.config.saveContainers", ModConfig.getInstance().isSaveContainers()));
    }

    private void updateCategoryVisibility() {
        // Remove all setting buttons
        remove(autoRecordButton);
        remove(autoExportButton);
        remove(autoExportOnDisconnectButton);
        remove(autoExportSingleplayerButton);
        remove(exportWithTexturePackButton);
        remove(saveContainersButton);

        if (currentCategory == Category.GENERAL) {
            addDrawableChild(autoRecordButton);
            addDrawableChild(autoExportButton);
            addDrawableChild(autoExportOnDisconnectButton);
            addDrawableChild(autoExportSingleplayerButton);
        } else {
            addDrawableChild(exportWithTexturePackButton);
            addDrawableChild(saveContainersButton);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Render background (vanilla uses blurred world background)
        super.render(context, mouseX, mouseY, delta);

        // Draw title centered at top
        Text title = Text.translatable("worlddownloader.config.title");
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);

        // Draw category label on right side
        Text categoryLabel = currentCategory == Category.GENERAL
            ? Text.translatable("worlddownloader.config.category.general")
            : Text.translatable("worlddownloader.config.category.export");
        context.drawText(textRenderer, categoryLabel, 190, 12, 0xAAAAAA, true);

        // Draw descriptions below each setting (after buttons so text appears on top)
        int rightX = 190;
        int buttonHeight = 20;
        int spacing = 8;
        int descriptionYOffset = buttonHeight + 2;
        int descriptionColor = 0xAAAAAA;

        if (currentCategory == Category.GENERAL) {
            Text autoRecordDesc = Text.translatable("worlddownloader.config.desc.autoRecord");
            context.drawText(textRenderer, autoRecordDesc, rightX,
                30 + descriptionYOffset, descriptionColor, true);

            Text autoExportDesc = Text.translatable("worlddownloader.config.desc.autoExport");
            context.drawText(textRenderer, autoExportDesc, rightX,
                30 + (buttonHeight + spacing) * 1 + descriptionYOffset, descriptionColor, true);

            Text autoExportDisconnectDesc = Text.translatable("worlddownloader.config.desc.autoExportOnDisconnect");
            context.drawText(textRenderer, autoExportDisconnectDesc, rightX,
                30 + (buttonHeight + spacing) * 2 + descriptionYOffset, descriptionColor, true);

            Text autoExportSingleplayerDesc = Text.translatable("worlddownloader.config.desc.autoExportSingleplayer");
            context.drawText(textRenderer, autoExportSingleplayerDesc, rightX,
                30 + (buttonHeight + spacing) * 3 + descriptionYOffset, descriptionColor, true);
        } else {
            Text texturePackDesc = Text.translatable("worlddownloader.config.desc.exportWithTexturePack");
            context.drawText(textRenderer, texturePackDesc, rightX,
                30 + descriptionYOffset, descriptionColor, true);

            Text saveContainersDesc = Text.translatable("worlddownloader.config.desc.saveContainers");
            context.drawText(textRenderer, saveContainersDesc, rightX,
                30 + (buttonHeight + spacing) * 1 + descriptionYOffset, descriptionColor, true);
        }
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    private enum Category {
        GENERAL,
        EXPORT
    }
}
