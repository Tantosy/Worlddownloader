package net.kuudraloremaster.worlddownloader;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.kuudraloremaster.worlddownloader.config.ModConfig;
import net.kuudraloremaster.worlddownloader.util.ChunkListener;
import net.kuudraloremaster.worlddownloader.util.ContainerTracker;
import net.kuudraloremaster.worlddownloader.util.EntityTracker;
import net.kuudraloremaster.worlddownloader.util.Exporter;
import net.kuudraloremaster.worlddownloader.util.WorldExporter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

@Environment(EnvType.CLIENT)
public class WorldDownloaderClient implements ClientModInitializer {

    private static KeyBinding exportKey;
    private static KeyBinding clearKey;

    /**
     * Pfad zum Server-Resource-Pack (wird gesetzt wenn wir einem Server mit Resource-Pack beitreten)
     */
    public static java.nio.file.Path resourcePackLocation;

    /**
     * Gibt an, ob aktuell automatisch aufgezeichnet wird (bei Auto-Record)
     */
    private static boolean isRecording = false;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = new KeyBinding.Category(net.minecraft.util.Identifier.of("worlddownloader", "category"));

        exportKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.worlddownloader.export",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_J,
                category
        ));

        clearKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.worlddownloader.clear",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                category
        ));

        // Server Join Event - für Auto-Record
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ModConfig config = ModConfig.getInstance();
            if (config.isAutoRecord()) {
                isRecording = true;
                System.out.println("[WorldDownloader] Auto-Record started for server: " + client.getCurrentServerEntry().name);
            }
        });

        // Server Leave Event - für Auto-Export beim Disconnect
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ModConfig config = ModConfig.getInstance();
            if (config.isAutoRecord() && config.isAutoExport() && isRecording) {
                isRecording = false;
                performAutoExport(client);
            } else if (config.isAutoExportOnDisconnect() && isRecording) {
                isRecording = false;
                performAutoExport(client);
            } else if (config.isAutoRecord() && isRecording) {
                // Auto-Record ist an, aber Auto-Export ist aus - Recording stoppen ohne Export
                isRecording = false;
                System.out.println("[WorldDownloader] Recording stopped. Press J to export manually.");
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (exportKey.wasPressed()) {
                int chunkCount = ChunkListener.getChunkCount();
                int entityCount = EntityTracker.getTotalTrackedEntities();
                int containerCount = ContainerTracker.getTotalSavedContainers();

                if (chunkCount == 0) {
                    System.out.println(" No chunks to export! Walk around to load chunks first.");
                    return;
                }

                Path worldFolder = ChunkListener.getWorldFolder();
                if (worldFolder == null) {
                    System.out.println(" Export folder nicht gefunden — wurden Chunks aufgezeichnet?");
                    return;
                }

                System.out.println(" Starting export of " + chunkCount + " chunks...");

                // Entities auf dem Game-Thread capturen (braucht Zugriff auf client)
                EntityTracker.captureAllEntities(client);
                System.out.println(" Capturing entities...");
                System.out.println(" Found " + entityCount + " entities and " + containerCount + " containers");

                // level.dat / playerdata / session.lock auf dem Game-Thread schreiben (klein + schnell)
                WorldExporter.createLoadableWorld(worldFolder.toFile());

                // MCA-Writes in Hintergrund-Thread — blockiert nicht den Game-Thread
                final Path exportFolder = worldFolder;
                final int finalChunkCount = chunkCount;
                final int finalEntityCount = entityCount;
                final int finalContainerCount = containerCount;
                Thread exportThread = new Thread(() -> {
                    try {
                        Exporter.exportChunks(exportFolder.toFile());
                        Exporter.exportEntities(exportFolder.toFile());
                        System.out.println(" World exported! Copy '" + exportFolder + "/' to '.minecraft/saves/'");
                        System.out.println(" Export Summary:");
                        System.out.println("    - Chunks: " + finalChunkCount);
                        System.out.println("    - Entities: " + finalEntityCount);
                        System.out.println("    - Containers: " + finalContainerCount);
                    } catch (Exception e) {
                        System.out.println(" Failed to export world: " + e.getMessage());
                        e.printStackTrace();
                    } finally {
                        // State zurücksetzen — nächster Export bekommt neuen Ordner
                        ChunkListener.clear();
                        EntityTracker.clear();
                        ContainerTracker.clear();
                    }
                }, "WD-ExportThread");
                exportThread.setDaemon(true);
                exportThread.start();
            }

            while (clearKey.wasPressed()) {
                int chunkCount = ChunkListener.getChunkCount();
                int entityCount = EntityTracker.getTotalTrackedEntities();
                int containerCount = ContainerTracker.getTotalSavedContainers();
                ChunkListener.clear();
                EntityTracker.captureAllEntities(client);
                ContainerTracker.clear();
                System.out.println(" Cleared cached data:");
                System.out.println("    - Chunks: " + chunkCount);
                System.out.println("    - Entities: " + entityCount);
                System.out.println("    - Containers: " + containerCount);
            }
        });
    }

    /**
     * Führt einen automatischen Export nach dem Verlassen eines Servers durch.
     * Wird im DISCONNECT Event aufgerufen, läuft also noch auf dem Client-Thread.
     */
    private static void performAutoExport(MinecraftClient client) {
        int chunkCount = ChunkListener.getChunkCount();
        int entityCount = EntityTracker.getTotalTrackedEntities();
        int containerCount = ContainerTracker.getTotalSavedContainers();

        if (chunkCount == 0) {
            System.out.println("[WorldDownloader] No chunks to export!");
            return;
        }

        Path worldFolder = ChunkListener.getWorldFolder();
        if (worldFolder == null) {
            System.out.println("[WorldDownloader] Export folder not found!");
            return;
        }

        System.out.println("[WorldDownloader] Starting auto-export of " + chunkCount + " chunks...");

        // Entities auf dem Game-Thread capturen
        EntityTracker.captureAllEntities(client);
        System.out.println(" Capturing entities...");
        System.out.println(" Found " + entityCount + " entities and " + containerCount + " containers");

        // level.dat / playerdata / session.lock auf dem Game-Thread schreiben
        WorldExporter.createLoadableWorld(worldFolder.toFile());

        // Texture Pack exportieren wenn aktiviert
        ModConfig config = ModConfig.getInstance();
        if (config.isExportWithTexturePack() && resourcePackLocation != null) {
            exportTexturePack(worldFolder);
        }

        // MCA-Writes in Hintergrund-Thread
        final Path exportFolder = worldFolder;
        final int finalChunkCount = chunkCount;
        final int finalEntityCount = entityCount;
        final int finalContainerCount = containerCount;
        Thread exportThread = new Thread(() -> {
            try {
                Exporter.exportChunks(exportFolder.toFile());
                Exporter.exportEntities(exportFolder.toFile());
                System.out.println("[WorldDownloader] World exported! Copy '" + exportFolder + "/' to '.minecraft/saves/'");
                System.out.println(" Export Summary:");
                System.out.println("    - Chunks: " + finalChunkCount);
                System.out.println("    - Entities: " + finalEntityCount);
                System.out.println("    - Containers: " + finalContainerCount);
            } catch (Exception e) {
                System.out.println(" Failed to export world: " + e.getMessage());
                e.printStackTrace();
            } finally {
                ChunkListener.clear();
                EntityTracker.clear();
                ContainerTracker.clear();
            }
        }, "WD-AutoExportThread");
        exportThread.setDaemon(true);
        exportThread.start();
    }

    /**
     * Exportiert das Server-Resource-Pack in den Weltordner.
     */
    private static void exportTexturePack(Path worldFolder) {
        if (resourcePackLocation == null || !resourcePackLocation.toFile().exists()) {
            System.out.println("[WorldDownloader] No texture pack found to export.");
            return;
        }

        try {
            Path resourcePackDir = worldFolder.resolve("resourcepack");
            java.nio.file.Files.createDirectories(resourcePackDir);

            File sourceFile = resourcePackLocation.toFile();
            File targetFile = resourcePackDir.resolve("server.zip").toFile();

            // Datei kopieren
            java.nio.file.Files.copy(resourcePackLocation, targetFile.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);

            // pack.mcmeta erstellen wenn nicht vorhanden
            Path mcmetaPath = resourcePackDir.resolve("pack.mcmeta");
            if (!mcmetaPath.toFile().exists()) {
                String mcmetaContent = """
                {
                  "pack": {
                    "pack_format": 18,
                    "description": "Server Resource Pack"
                  }
                }
                """;
                java.nio.file.Files.writeString(mcmetaPath, mcmetaContent);
            }

            System.out.println("[WorldDownloader] Texture pack exported to: " + resourcePackDir);
        } catch (IOException e) {
            System.out.println("[WorldDownloader] Failed to export texture pack: " + e.getMessage());
        }
    }
}
