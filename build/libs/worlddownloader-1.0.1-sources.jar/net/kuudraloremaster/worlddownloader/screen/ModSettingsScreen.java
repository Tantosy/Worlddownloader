package net.kuudraloremaster.worlddownloader.screen;

import net.kuudraloremaster.worlddownloader.config.ModConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Settings screen for World Downloader with modern two-column layout.
 * Left: Category list (General, Export)
 * Right: Settings with ON/OFF toggles and descriptions
 */
public class ModSettingsScreen extends class_437 {

    private final class_437 parent;
    private Category currentCategory = Category.GENERAL;

    // Category buttons
    private class_4185 generalButton;
    private class_4185 exportButton;

    // General settings
    private class_4185 autoRecordButton;
    private class_4185 autoExportButton;
    private class_4185 autoExportOnDisconnectButton;
    private class_4185 autoExportSingleplayerButton;

    // Export settings
    private class_4185 exportWithTexturePackButton;
    private class_4185 saveContainersButton;

    // Common buttons
    private class_4185 resetButton;
    private class_4185 doneButton;

    public ModSettingsScreen(class_437 parent) {
        super(class_2561.method_43471("worlddownloader.config.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int leftPanelWidth = 150;
        int leftX = 20;
        int rightX = leftX + leftPanelWidth + 20;
        int rightPanelWidth = field_22789 - rightX - 20;
        int buttonHeight = 20;
        int spacing = 8;

        // === LEFT PANEL - Categories ===
        int categoryY = 30;
        generalButton = class_4185.method_46430(
            class_2561.method_43471("worlddownloader.config.category.general"),
            b -> switchCategory(Category.GENERAL)
        ).method_46434(leftX, categoryY, leftPanelWidth, buttonHeight).method_46431();

        exportButton = class_4185.method_46430(
            class_2561.method_43471("worlddownloader.config.category.export"),
            b -> switchCategory(Category.EXPORT)
        ).method_46434(leftX, categoryY + buttonHeight + spacing, leftPanelWidth, buttonHeight).method_46431();

        method_37063(generalButton);
        method_37063(exportButton);

        // === RIGHT PANEL - Settings ===
        int settingStartY = 30;
        int settingButtonWidth = rightPanelWidth;

        // General settings
        autoRecordButton = class_4185.method_46430(
            getToggleText("worlddownloader.config.autoRecord", ModConfig.getInstance().isAutoRecord()),
            b -> toggleAutoRecord()
        ).method_46434(rightX, settingStartY, settingButtonWidth, buttonHeight).method_46431();

        autoExportButton = class_4185.method_46430(
            getToggleText("worlddownloader.config.autoExport", ModConfig.getInstance().isAutoExport()),
            b -> toggleAutoExport()
        ).method_46434(rightX, settingStartY + (buttonHeight + spacing) * 1, settingButtonWidth, buttonHeight).method_46431();

        autoExportOnDisconnectButton = class_4185.method_46430(
            getToggleText("worlddownloader.config.autoExportOnDisconnect", ModConfig.getInstance().isAutoExportOnDisconnect()),
            b -> toggleAutoExportOnDisconnect()
        ).method_46434(rightX, settingStartY + (buttonHeight + spacing) * 2, settingButtonWidth, buttonHeight).method_46431();

        autoExportSingleplayerButton = class_4185.method_46430(
            getToggleText("worlddownloader.config.autoExportSingleplayer", ModConfig.getInstance().isAutoExportSingleplayer()),
            b -> toggleAutoExportSingleplayer()
        ).method_46434(rightX, settingStartY + (buttonHeight + spacing) * 3, settingButtonWidth, buttonHeight).method_46431();

        // Export settings
        exportWithTexturePackButton = class_4185.method_46430(
            getToggleText("worlddownloader.config.exportWithTexturePack", ModConfig.getInstance().isExportWithTexturePack()),
            b -> toggleExportWithTexturePack()
        ).method_46434(rightX, settingStartY, settingButtonWidth, buttonHeight).method_46431();

        saveContainersButton = class_4185.method_46430(
            getToggleText("worlddownloader.config.saveContainers", ModConfig.getInstance().isSaveContainers()),
            b -> toggleSaveContainers()
        ).method_46434(rightX, settingStartY + (buttonHeight + spacing) * 1, settingButtonWidth, buttonHeight).method_46431();

        // Reset button (bottom left)
        resetButton = class_4185.method_46430(
            class_2561.method_43471("worlddownloader.config.reset"),
            b -> resetToDefaults()
        ).method_46434(leftX, field_22790 - 50, leftPanelWidth, buttonHeight).method_46431();

        // Done button (bottom center)
        doneButton = class_4185.method_46430(
            class_2561.method_43471("worlddownloader.config.done"),
            b -> method_25419()
        ).method_46434(field_22789 / 2 - 100, field_22790 - 30, 200, buttonHeight).method_46431();

        method_37063(resetButton);
        method_37063(doneButton);

        updateCategoryVisibility();
        updateCategoryButtons();
    }

    private void switchCategory(Category category) {
        currentCategory = category;
        updateCategoryVisibility();
        updateCategoryButtons();
    }

    private void updateCategoryButtons() {
        // Highlight selected category
        generalButton.method_25355(class_2561.method_43471("worlddownloader.config.category.general")
            .method_27661().method_27692(currentCategory == Category.GENERAL ? class_124.field_1068 : class_124.field_1080));
        exportButton.method_25355(class_2561.method_43471("worlddownloader.config.category.export")
            .method_27661().method_27692(currentCategory == Category.EXPORT ? class_124.field_1068 : class_124.field_1080));
    }

    private class_2561 getToggleText(String translationKey, boolean value) {
        class_2561 name = class_2561.method_43471(translationKey);
        class_2561 status = class_2561.method_43471(value ? "worlddownloader.config.on" : "worlddownloader.config.off")
            .method_27692(value ? class_124.field_1060 : class_124.field_1061);
        return name.method_27661().method_10852(class_2561.method_43470(": ")).method_10852(status);
    }

    private void toggleAutoRecord() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoRecord(!config.isAutoRecord());
        autoRecordButton.method_25355(getToggleText("worlddownloader.config.autoRecord", config.isAutoRecord()));
    }

    private void toggleAutoExport() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoExport(!config.isAutoExport());
        autoExportButton.method_25355(getToggleText("worlddownloader.config.autoExport", config.isAutoExport()));
    }

    private void toggleAutoExportOnDisconnect() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoExportOnDisconnect(!config.isAutoExportOnDisconnect());
        autoExportOnDisconnectButton.method_25355(getToggleText("worlddownloader.config.autoExportOnDisconnect", config.isAutoExportOnDisconnect()));
    }

    private void toggleAutoExportSingleplayer() {
        ModConfig config = ModConfig.getInstance();
        config.setAutoExportSingleplayer(!config.isAutoExportSingleplayer());
        autoExportSingleplayerButton.method_25355(getToggleText("worlddownloader.config.autoExportSingleplayer", config.isAutoExportSingleplayer()));
    }

    private void toggleExportWithTexturePack() {
        ModConfig config = ModConfig.getInstance();
        config.setExportWithTexturePack(!config.isExportWithTexturePack());
        exportWithTexturePackButton.method_25355(getToggleText("worlddownloader.config.exportWithTexturePack", config.isExportWithTexturePack()));
    }

    private void toggleSaveContainers() {
        ModConfig config = ModConfig.getInstance();
        config.setSaveContainers(!config.isSaveContainers());
        saveContainersButton.method_25355(getToggleText("worlddownloader.config.saveContainers", config.isSaveContainers()));
    }

    private void resetToDefaults() {
        ModConfig.getInstance().resetToDefaults();
        autoRecordButton.method_25355(getToggleText("worlddownloader.config.autoRecord", ModConfig.getInstance().isAutoRecord()));
        autoExportButton.method_25355(getToggleText("worlddownloader.config.autoExport", ModConfig.getInstance().isAutoExport()));
        autoExportOnDisconnectButton.method_25355(getToggleText("worlddownloader.config.autoExportOnDisconnect", ModConfig.getInstance().isAutoExportOnDisconnect()));
        autoExportSingleplayerButton.method_25355(getToggleText("worlddownloader.config.autoExportSingleplayer", ModConfig.getInstance().isAutoExportSingleplayer()));
        exportWithTexturePackButton.method_25355(getToggleText("worlddownloader.config.exportWithTexturePack", ModConfig.getInstance().isExportWithTexturePack()));
        saveContainersButton.method_25355(getToggleText("worlddownloader.config.saveContainers", ModConfig.getInstance().isSaveContainers()));
    }

    private void updateCategoryVisibility() {
        // Remove all setting buttons
        method_37066(autoRecordButton);
        method_37066(autoExportButton);
        method_37066(autoExportOnDisconnectButton);
        method_37066(autoExportSingleplayerButton);
        method_37066(exportWithTexturePackButton);
        method_37066(saveContainersButton);

        if (currentCategory == Category.GENERAL) {
            method_37063(autoRecordButton);
            method_37063(autoExportButton);
            method_37063(autoExportOnDisconnectButton);
            method_37063(autoExportSingleplayerButton);
        } else {
            method_37063(exportWithTexturePackButton);
            method_37063(saveContainersButton);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Render background (vanilla uses blurred world background)
        super.method_25394(context, mouseX, mouseY, delta);

        // Draw title centered at top
        class_2561 title = class_2561.method_43471("worlddownloader.config.title");
        context.method_27534(field_22793, title, field_22789 / 2, 12, 0xFFFFFF);

        // Draw category label on right side
        class_2561 categoryLabel = currentCategory == Category.GENERAL
            ? class_2561.method_43471("worlddownloader.config.category.general")
            : class_2561.method_43471("worlddownloader.config.category.export");
        context.method_51439(field_22793, categoryLabel, 190, 12, 0xAAAAAA, true);

        // Draw descriptions below each setting (after buttons so text appears on top)
        int rightX = 190;
        int buttonHeight = 20;
        int spacing = 8;
        int descriptionYOffset = buttonHeight + 2;
        int descriptionColor = 0xAAAAAA;

        if (currentCategory == Category.GENERAL) {
            class_2561 autoRecordDesc = class_2561.method_43471("worlddownloader.config.desc.autoRecord");
            context.method_51439(field_22793, autoRecordDesc, rightX,
                30 + descriptionYOffset, descriptionColor, true);

            class_2561 autoExportDesc = class_2561.method_43471("worlddownloader.config.desc.autoExport");
            context.method_51439(field_22793, autoExportDesc, rightX,
                30 + (buttonHeight + spacing) * 1 + descriptionYOffset, descriptionColor, true);

            class_2561 autoExportDisconnectDesc = class_2561.method_43471("worlddownloader.config.desc.autoExportOnDisconnect");
            context.method_51439(field_22793, autoExportDisconnectDesc, rightX,
                30 + (buttonHeight + spacing) * 2 + descriptionYOffset, descriptionColor, true);

            class_2561 autoExportSingleplayerDesc = class_2561.method_43471("worlddownloader.config.desc.autoExportSingleplayer");
            context.method_51439(field_22793, autoExportSingleplayerDesc, rightX,
                30 + (buttonHeight + spacing) * 3 + descriptionYOffset, descriptionColor, true);
        } else {
            class_2561 texturePackDesc = class_2561.method_43471("worlddownloader.config.desc.exportWithTexturePack");
            context.method_51439(field_22793, texturePackDesc, rightX,
                30 + descriptionYOffset, descriptionColor, true);

            class_2561 saveContainersDesc = class_2561.method_43471("worlddownloader.config.desc.saveContainers");
            context.method_51439(field_22793, saveContainersDesc, rightX,
                30 + (buttonHeight + spacing) * 1 + descriptionYOffset, descriptionColor, true);
        }
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    private enum Category {
        GENERAL,
        EXPORT
    }
}
