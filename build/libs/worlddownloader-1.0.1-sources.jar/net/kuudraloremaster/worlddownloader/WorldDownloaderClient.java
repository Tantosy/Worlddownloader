package net.kuudraloremaster.worlddownloader;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.kuudraloremaster.worlddownloader.util.ChunkListener;
import net.kuudraloremaster.worlddownloader.util.ContainerTracker;
import net.kuudraloremaster.worlddownloader.util.EntityTracker;
import net.kuudraloremaster.worlddownloader.util.Exporter;
import net.kuudraloremaster.worlddownloader.util.WorldExporter;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Path;

@Environment(EnvType.CLIENT)
public class WorldDownloaderClient implements ClientModInitializer {

    private static class_304 exportKey;
    private static class_304 clearKey;

    @Override
    public void onInitializeClient() {
        class_304.class_11900 category = new class_304.class_11900(net.minecraft.class_2960.method_60655("worlddownloader", "category"));

        exportKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.worlddownloader.export",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                category
        ));

        clearKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.worlddownloader.clear",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (exportKey.method_1436()) {
                int chunkCount = ChunkListener.getChunkCount();
                int entityCount = EntityTracker.getTotalTrackedEntities();
                int containerCount = ContainerTracker.getTotalSavedContainers();

                if (chunkCount == 0) {
                    System.out.println(" No chunks to export! Walk around to load chunks first.");
                    return;
                }

                System.out.println(" Starting export of " + chunkCount + " chunks...");
                System.out.println(" Capturing entities...");
                EntityTracker.captureAllEntities(client);
                System.out.println(" Found " + entityCount + " entities and " + containerCount + " containers");

                try {
                    Path worldFolder = ChunkListener.getWorldFolder();
                    if (worldFolder == null) {
                        System.out.println(" Export folder nicht gefunden — wurden Chunks aufgezeichnet?");
                        return;
                    }

                    WorldExporter.createLoadableWorld(worldFolder.toFile());
                    Exporter.exportChunks(worldFolder.toFile());
                    Exporter.exportEntities(worldFolder.toFile());

                    System.out.println(" World exported! Copy '" + worldFolder + "/' to '.minecraft/saves/'");
                    System.out.println(" Export Summary:");
                    System.out.println("    - Chunks: " + chunkCount);
                    System.out.println("    - Entities: " + entityCount);
                    System.out.println("    - Containers: " + containerCount);
                } catch (Exception e) {
                    System.out.println(" Failed to export world: " + e.getMessage());
                    e.printStackTrace();
                }
            }

            while (clearKey.method_1436()) {
                int chunkCount = ChunkListener.getChunkCount();
                int entityCount = EntityTracker.getTotalTrackedEntities();
                int containerCount = ContainerTracker.getTotalSavedContainers();
                ChunkListener.clear();
                EntityTracker.captureAllEntities(client);
                ContainerTracker.clear();
                System.out.println(" Cleared cached data:");
                System.out.println("    - Chunks: " + chunkCount);
                System.out.println("    - Entities: " + entityCount);
                System.out.println("    - Containers: " + containerCount);
            }
        });
    }
}
