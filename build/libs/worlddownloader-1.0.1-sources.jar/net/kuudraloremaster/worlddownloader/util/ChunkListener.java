package net.kuudraloremaster.worlddownloader.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public class ChunkListener {

    private static final Map<class_1923, class_2487> downloadedChunkNbt = new ConcurrentHashMap<>();

    public static void addChunkNbt(class_1923 chunkPos, class_2487 chunkNbt) {
        downloadedChunkNbt.put(chunkPos, chunkNbt);
        System.out.println("[WorldDownloader] Captured raw NBT chunk: " + chunkPos.field_9181 + "," + chunkPos.field_9180);
    }

    public static Map<class_1923, class_2487> getAll() {
        return downloadedChunkNbt;
    }

    public static int getDataVersion() {
        for (class_2487 chunk : downloadedChunkNbt.values()) {
            var v = chunk.method_10550("DataVersion");
            if (v.isPresent() && v.get() != 0) return v.get();
        }
        return 4671; // fallback (1.21.11)
    }

    public static void clear() {
        downloadedChunkNbt.clear();
    }
}
