package net.kuudraloremaster.worlddownloader.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2861;
import net.minecraft.class_9240;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

@Environment(EnvType.CLIENT)
public class ChunkListener {

    private record ChunkEntry(class_1923 pos, class_2487 nbt) {}

    private static final DateTimeFormatter TIMESTAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm");

    private static final ConcurrentLinkedQueue<ChunkEntry> saveQueue = new ConcurrentLinkedQueue<>();
    private static final Map<Long, class_2861> openRegionFiles = new HashMap<>();
    private static final AtomicInteger chunkCount = new AtomicInteger(0);
    private static volatile int dataVersion = 4671;
    private static volatile boolean running = false;
    private static Thread saveThread;
    private static Path worldFolder; // z.B. downloaded_worlds/Export_2024-01-15_14-30
    private static Path regionDir;   // worldFolder/region
    private static final Object startLock = new Object();

    public static void addChunkNbt(class_1923 chunkPos, class_2487 chunkNbt) {
        var v = chunkNbt.method_10550("DataVersion");
        if (v.isPresent() && v.get() != 0) {
            dataVersion = v.get();
        }

        saveQueue.add(new ChunkEntry(chunkPos, chunkNbt));
        chunkCount.incrementAndGet();
        System.out.println("[WorldDownloader] Queued chunk: " + chunkPos.field_9181 + "," + chunkPos.field_9180);

        if (!running) {
            synchronized (startLock) {
                if (!running) {
                    startSaveThread();
                }
            }
        }
    }

    private static void startSaveThread() {
        // Jeder Export bekommt einen eigenen Ordner — keine Kollisionen zwischen Sessions
        String exportName = "Export_" + LocalDateTime.now().format(TIMESTAMP);
        worldFolder = Path.of("downloaded_worlds", exportName);
        regionDir = worldFolder.resolve("region");
        try {
            Files.createDirectories(regionDir);
        } catch (IOException e) {
            System.out.println("[WD] Failed to create region directory: " + e.getMessage());
        }

        running = true;
        saveThread = new Thread(ChunkListener::saveLoop, "WD-ChunkSaver");
        saveThread.setDaemon(true);
        saveThread.start();
        System.out.println("[WorldDownloader] Save thread started → " + worldFolder);
    }

    private static void saveLoop() {
        while (running || !saveQueue.isEmpty()) {
            ChunkEntry entry = saveQueue.poll();
            if (entry == null) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    break;
                }
                continue;
            }
            writeChunk(entry.pos, entry.nbt);
        }
        closeAllRegionFiles();
    }

    private static void writeChunk(class_1923 pos, class_2487 nbt) {
        try {
            int rx = Math.floorDiv(pos.field_9181, 32);
            int rz = Math.floorDiv(pos.field_9180, 32);
            long regionKey = ((long) rx << 32) | (rz & 0xFFFFFFFFL);

            class_2861 regionFile = openRegionFiles.get(regionKey);
            if (regionFile == null) {
                Path path = regionDir.resolve(String.format("r.%d.%d.mca", rx, rz));
                class_9240 storageKey = new class_9240("downloaded_world", class_1937.field_25179, "chunk");
                regionFile = new class_2861(storageKey, path, regionDir, true);
                openRegionFiles.put(regionKey, regionFile);
            }

            try (DataOutputStream out = regionFile.method_21881(pos)) {
                class_2507.method_55324(nbt, out);
            }
        } catch (Exception e) {
            System.out.println("[WD] Failed to save chunk " + pos.field_9181 + "," + pos.field_9180 + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void flush() {
        if (!running) return;
        while (!saveQueue.isEmpty()) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    public static void stop() {
        running = false;
        if (saveThread != null) {
            try {
                saveThread.join(5000);
            } catch (InterruptedException e) {
                // ignored
            }
            saveThread = null;
        }
        closeAllRegionFiles();
    }

    private static void closeAllRegionFiles() {
        for (class_2861 rf : openRegionFiles.values()) {
            try {
                rf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        openRegionFiles.clear();
    }

    public static int getChunkCount() {
        return chunkCount.get();
    }

    public static int getDataVersion() {
        return dataVersion;
    }

    public static Path getWorldFolder() {
        return worldFolder;
    }

    public static void clear() {
        stop();
        saveQueue.clear();
        chunkCount.set(0);
        dataVersion = 4671;
        worldFolder = null;
        regionDir = null;
    }
}
