package net.kuudraloremaster.worlddownloader.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class Exporter {

    public static void exportChunks(File worldFolder) throws IOException {
        int chunkCount = ChunkListener.getChunkCount();

        if (chunkCount == 0) {
            System.out.println(" No chunks to export!");
            return;
        }

        ChunkListener.flush();

        int totalContainers = ContainerTracker.getTotalSavedContainers();
        int totalEntities = EntityTracker.getTotalTrackedEntities();

        System.out.println(" Exported " + chunkCount + " chunks with " +
                totalContainers + " containers to region files.");
    }

    public static void exportEntities(File worldFolder) throws IOException {
        Map<class_1923, List<class_2487>> allEntities = EntityTracker.getAll();
        if (allEntities.isEmpty()) return;

        Path entitiesDir = worldFolder.toPath().resolve("entities");
        Files.createDirectories(entitiesDir);

        int dataVersion = ChunkListener.getDataVersion();

        // Nach Region gruppieren
        Map<Long, Map<class_1923, class_2487>> regionChunks = new HashMap<>();
        for (Map.Entry<class_1923, List<class_2487>> entry : allEntities.entrySet()) {
            class_1923 pos = entry.getKey();
            int rx = Math.floorDiv(pos.field_9181, 32);
            int rz = Math.floorDiv(pos.field_9180, 32);
            long regionKey = ((long) rx << 32) | (rz & 0xFFFFFFFFL);

            class_2487 chunk = new class_2487();
            chunk.method_10569("DataVersion", dataVersion);
            chunk.method_10539("Position", new int[]{pos.field_9181, pos.field_9180});
            class_2499 entityList = new class_2499();
            entityList.addAll(entry.getValue());
            chunk.method_10566("Entities", entityList);

            regionChunks.computeIfAbsent(regionKey, k -> new HashMap<>()).put(pos, chunk);
        }

        for (Map.Entry<Long, Map<class_1923, class_2487>> regionEntry : regionChunks.entrySet()) {
            long regionKey = regionEntry.getKey();
            int rx = (int) (regionKey >> 32);
            int rz = (int) regionKey;
            Path regionPath = entitiesDir.resolve(String.format("r.%d.%d.mca", rx, rz));

            try {
                ChunkListener.writeMcaFile(regionPath, regionEntry.getValue());
                System.out.println(" Successfully wrote entity region: " + regionPath.getFileName());
            } catch (IOException e) {
                System.out.println(" Failed to write entity region: " + e.getMessage());
                e.printStackTrace();
            }
        }

        System.out.println(" Entities exported to entities/ folder.");
    }
}
