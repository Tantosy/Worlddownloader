package net.kuudraloremaster.worlddownloader.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2494;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2519;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4844;
import net.minecraft.class_638;
import net.minecraft.class_7923;
import net.minecraft.nbt.*;
import java.io.*;
import java.nio.file.Files;

@Environment(EnvType.CLIENT)
public class WorldExporter {

    public static void createLoadableWorld(File worldFolder) {
        try {
            class_310 client = class_310.method_1551();

            new File(worldFolder, "region").mkdirs();
            new File(worldFolder, "entities").mkdirs();
            new File(worldFolder, "playerdata").mkdirs();
            new File(worldFolder, "stats").mkdirs();
            new File(worldFolder, "advancements").mkdirs();
            new File(worldFolder, "data").mkdirs();
            new File(worldFolder, "poi").mkdirs();

            // session.lock
            try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(new File(worldFolder, "session.lock")))) {
                dos.writeLong(System.currentTimeMillis());
            }

            writeLevelDat(worldFolder, client);
            writePlayerData(worldFolder, client);
            writeEmptyAdvancements(worldFolder, client);
            writeEmptyStats(worldFolder, client);

            System.out.println(" World structure created at: " + worldFolder.getAbsolutePath());
        } catch (Exception e) {
            System.out.println(" Failed to create world structure: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void writeLevelDat(File worldFolder, class_310 client) throws IOException {
        int dataVersion = ChunkListener.getDataVersion();
        String versionName = "1.21.11";

        class_2487 levelDat = new class_2487();
        levelDat.method_10569("DataVersion", dataVersion);
        levelDat.method_10582("LevelName", "Downloaded World");
        levelDat.method_10544("LastPlayed", System.currentTimeMillis());
        levelDat.method_10544("Time", client.field_1687 != null ? client.field_1687.method_75260() : 0L);
        levelDat.method_10544("DayTime", client.field_1687 != null ? client.field_1687.method_8532() : 6000L);
        levelDat.method_10569("GameType", 1); // Creative
        levelDat.method_10556("hardcore", false);
        levelDat.method_10556("allowCommands", false);
        levelDat.method_10567("Difficulty", (byte) 2);
        levelDat.method_10556("DifficultyLocked", false);
        levelDat.method_10567("initialized", (byte) 1);
        levelDat.method_10569("version", 19133);

        // Spawn (1.21.11 format) — find valid position: feet+head=air, block below=solid
        int spawnX = 0, spawnY = 64, spawnZ = 0;
        if (client.field_1724 != null && client.field_1687 != null) {
            spawnX = class_3532.method_15357(client.field_1724.method_23317());
            spawnZ = class_3532.method_15357(client.field_1724.method_23321());
            spawnY = findSafeSpawnY(client.field_1687, spawnX, spawnZ);
        }
        class_2487 spawn = new class_2487();
        spawn.method_10539("pos", new int[]{spawnX, spawnY, spawnZ});
        spawn.method_10548("pitch", 0f);
        spawn.method_10548("yaw", client.field_1724 != null ? client.field_1724.method_36454() : 0f);
        spawn.method_10582("dimension", "minecraft:overworld");
        levelDat.method_10566("spawn", spawn);

        // Version
        class_2487 version = new class_2487();
        version.method_10569("Id", dataVersion);
        version.method_10582("Name", versionName);
        version.method_10582("Series", "main");
        version.method_10556("Snapshot", false);
        levelDat.method_10566("Version", version);

        // WorldGenSettings
        class_2487 worldGenSettings = new class_2487();
        worldGenSettings.method_10544("seed", 0L);
        worldGenSettings.method_10556("generate_features", true);
        worldGenSettings.method_10556("bonus_chest", false);
        class_2487 dimensions = new class_2487();

        class_2487 overworld = new class_2487();
        class_2487 overworldGen = new class_2487();
        overworldGen.method_10582("type", "minecraft:noise");
        overworldGen.method_10582("settings", "minecraft:overworld");
        class_2487 overworldBiomeSource = new class_2487();
        overworldBiomeSource.method_10582("preset", "minecraft:overworld");
        overworldBiomeSource.method_10582("type", "minecraft:multi_noise");
        overworldGen.method_10566("biome_source", overworldBiomeSource);
        overworld.method_10566("generator", overworldGen);
        overworld.method_10582("type", "minecraft:overworld");
        dimensions.method_10566("minecraft:overworld", overworld);

        class_2487 nether = new class_2487();
        class_2487 netherGen = new class_2487();
        netherGen.method_10582("type", "minecraft:noise");
        netherGen.method_10582("settings", "minecraft:nether");
        class_2487 netherBiomeSource = new class_2487();
        netherBiomeSource.method_10582("preset", "minecraft:nether");
        netherBiomeSource.method_10582("type", "minecraft:multi_noise");
        netherGen.method_10566("biome_source", netherBiomeSource);
        nether.method_10566("generator", netherGen);
        nether.method_10582("type", "minecraft:the_nether");
        dimensions.method_10566("minecraft:the_nether", nether);

        class_2487 end = new class_2487();
        class_2487 endGen = new class_2487();
        endGen.method_10582("type", "minecraft:noise");
        endGen.method_10582("settings", "minecraft:end");
        class_2487 endBiomeSource = new class_2487();
        endBiomeSource.method_10582("type", "minecraft:the_end");
        endGen.method_10566("biome_source", endBiomeSource);
        end.method_10566("generator", endGen);
        end.method_10582("type", "minecraft:the_end");
        dimensions.method_10566("minecraft:the_end", end);

        worldGenSettings.method_10566("dimensions", dimensions);
        levelDat.method_10566("WorldGenSettings", worldGenSettings);

        // Game rules (1.21.11 format: byte values with minecraft: prefix)
        class_2487 gameRules = new class_2487();
        gameRules.method_10567("minecraft:block_drops", (byte) 1);
        gameRules.method_10567("minecraft:advance_time", (byte) 1);
        gameRules.method_10567("minecraft:advance_weather", (byte) 1);
        gameRules.method_10567("minecraft:command_blocks_work", (byte) 1);
        gameRules.method_10567("minecraft:command_block_output", (byte) 1);
        gameRules.method_10567("minecraft:drowning_damage", (byte) 1);
        gameRules.method_10567("minecraft:entity_drops", (byte) 1);
        gameRules.method_10567("minecraft:fall_damage", (byte) 1);
        gameRules.method_10567("minecraft:fire_damage", (byte) 1);
        gameRules.method_10569("minecraft:fire_spread_radius_around_player", 128);
        gameRules.method_10567("minecraft:forgive_dead_players", (byte) 1);
        gameRules.method_10567("minecraft:freeze_damage", (byte) 1);
        gameRules.method_10567("minecraft:global_sound_events", (byte) 1);
        gameRules.method_10567("minecraft:immediate_respawn", (byte) 0);
        gameRules.method_10567("minecraft:keep_inventory", (byte) 0);
        gameRules.method_10567("minecraft:lava_source_conversion", (byte) 0);
        gameRules.method_10567("minecraft:limited_crafting", (byte) 0);
        gameRules.method_10567("minecraft:locator_bar", (byte) 1);
        gameRules.method_10567("minecraft:log_admin_commands", (byte) 1);
        gameRules.method_10569("minecraft:max_block_modifications", 32768);
        gameRules.method_10569("minecraft:max_command_forks", 65536);
        gameRules.method_10569("minecraft:max_command_sequence_length", 65536);
        gameRules.method_10569("minecraft:max_entity_cramming", 24);
        gameRules.method_10569("minecraft:max_snow_accumulation_height", 1);
        gameRules.method_10567("minecraft:mob_drops", (byte) 1);
        gameRules.method_10567("minecraft:mob_explosion_drop_decay", (byte) 1);
        gameRules.method_10567("minecraft:block_explosion_drop_decay", (byte) 1);
        gameRules.method_10567("minecraft:tnt_explosion_drop_decay", (byte) 0);
        gameRules.method_10567("minecraft:mob_griefing", (byte) 1);
        gameRules.method_10567("minecraft:natural_health_regeneration", (byte) 1);
        gameRules.method_10567("minecraft:player_movement_check", (byte) 1);
        gameRules.method_10567("minecraft:elytra_movement_check", (byte) 1);
        gameRules.method_10569("minecraft:players_nether_portal_creative_delay", 0);
        gameRules.method_10569("minecraft:players_nether_portal_default_delay", 80);
        gameRules.method_10569("minecraft:players_sleeping_percentage", 100);
        gameRules.method_10567("minecraft:projectiles_can_break_blocks", (byte) 1);
        gameRules.method_10567("minecraft:pvp", (byte) 1);
        gameRules.method_10567("minecraft:raids", (byte) 1);
        gameRules.method_10569("minecraft:random_tick_speed", 3);
        gameRules.method_10567("minecraft:reduced_debug_info", (byte) 0);
        gameRules.method_10569("minecraft:respawn_radius", 10);
        gameRules.method_10567("minecraft:send_command_feedback", (byte) 1);
        gameRules.method_10567("minecraft:show_advancement_messages", (byte) 1);
        gameRules.method_10567("minecraft:show_death_messages", (byte) 1);
        gameRules.method_10567("minecraft:spawn_mobs", (byte) 1);
        gameRules.method_10567("minecraft:spawn_monsters", (byte) 1);
        gameRules.method_10567("minecraft:spawn_patrols", (byte) 1);
        gameRules.method_10567("minecraft:spawn_phantoms", (byte) 1);
        gameRules.method_10567("minecraft:spawn_wandering_traders", (byte) 1);
        gameRules.method_10567("minecraft:spawn_wardens", (byte) 1);
        gameRules.method_10567("minecraft:spawner_blocks_work", (byte) 1);
        gameRules.method_10567("minecraft:spectators_generate_chunks", (byte) 1);
        gameRules.method_10567("minecraft:spread_vines", (byte) 1);
        gameRules.method_10567("minecraft:tnt_explodes", (byte) 1);
        gameRules.method_10567("minecraft:universal_anger", (byte) 0);
        gameRules.method_10567("minecraft:water_source_conversion", (byte) 1);
        gameRules.method_10567("minecraft:allow_entering_nether_using_portals", (byte) 1);
        gameRules.method_10567("minecraft:ender_pearls_vanish_on_death", (byte) 1);
        levelDat.method_10566("game_rules", gameRules);

        // DataPacks
        class_2487 dataPacks = new class_2487();
        class_2499 enabled = new class_2499();
        enabled.add(class_2519.method_23256("vanilla"));
        dataPacks.method_10566("Enabled", enabled);
        dataPacks.method_10566("Disabled", new class_2499());
        levelDat.method_10566("DataPacks", dataPacks);

        // Weather & misc
        levelDat.method_10567("raining", (byte) 0);
        levelDat.method_10567("thundering", (byte) 0);
        levelDat.method_10569("rainTime", 0);
        levelDat.method_10569("thunderTime", 0);
        levelDat.method_10569("clearWeatherTime", 0);

        class_2487 dataWrapper = new class_2487();
        dataWrapper.method_10566("Data", levelDat);

        class_2507.method_30614(dataWrapper, worldFolder.toPath().resolve("level.dat"));
        System.out.println(" level.dat written (DataVersion=" + dataVersion + ", MC=" + versionName + ")");
    }

    private static void writePlayerData(File worldFolder, class_310 client) throws IOException {
        if (client.field_1724 == null || client.field_1687 == null) return;

        int dataVersion = ChunkListener.getDataVersion();
        String uuid = client.field_1724.method_5667().toString();

        class_2487 player = new class_2487();
        player.method_10569("DataVersion", dataVersion);
        player.method_10569("playerGameType", 1); // Creative
        player.method_10548("Health", client.field_1724.method_6032());
        player.method_10569("foodLevel", client.field_1724.method_7344().method_7586());
        player.method_10548("foodSaturationLevel", client.field_1724.method_7344().method_7589());
        player.method_10548("XpP", client.field_1724.field_7510);
        player.method_10569("XpLevel", client.field_1724.field_7520);
        player.method_10569("XpTotal", client.field_1724.field_7495);
        player.method_10575("Fire", (short) 0);
        player.method_10575("Air", (short) client.field_1724.method_5669());
        player.method_10556("OnGround", true);
        player.method_10548("FallDistance", 0.0f);
        player.method_10569("HurtResistantTime", 60); // 3 seconds of damage immunity after spawn
        player.method_10556("Invulnerable", client.field_1724.method_5655());
        player.method_10539("UUID", class_4844.method_26275(client.field_1724.method_5667()));

        // Find a valid spawn position: feet=air, head=air, ground below=solid
        int safeY = findSafeSpawnY(client.field_1687, class_3532.method_15357(client.field_1724.method_23317()),
                class_3532.method_15357(client.field_1724.method_23321()));
        class_2499 pos = new class_2499();
        pos.add(class_2489.method_23241(client.field_1724.method_23317()));
        pos.add(class_2489.method_23241(safeY));
        pos.add(class_2489.method_23241(client.field_1724.method_23321()));
        player.method_10566("Pos", pos);

        class_2499 motion = new class_2499();
        motion.add(class_2489.method_23241(0));
        motion.add(class_2489.method_23241(0));
        motion.add(class_2489.method_23241(0));
        player.method_10566("Motion", motion);

        class_2499 rotation = new class_2499();
        rotation.add(class_2494.method_23244(client.field_1724.method_36454()));
        rotation.add(class_2494.method_23244(client.field_1724.method_36455()));
        player.method_10566("Rotation", rotation);

        class_2499 inventory = new class_2499();
        for (int i = 0; i < client.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960()) {
                class_2487 itemNbt = new class_2487();
                itemNbt.method_10567("Slot", (byte) i);
                itemNbt.method_10582("id", class_7923.field_41178.method_10221(stack.method_7909()).toString());
                itemNbt.method_10569("count", stack.method_7947());
                inventory.add(itemNbt);
            }
        }
        player.method_10566("Inventory", inventory);
        player.method_10566("EnderItems", new class_2499());
        player.method_10582("Dimension", "minecraft:overworld");

        class_2487 abilities = new class_2487();
        abilities.method_10548("walkSpeed", 0.1f);
        abilities.method_10548("flySpeed", 0.05f);
        abilities.method_10556("mayfly", false);
        abilities.method_10556("flying", false);
        abilities.method_10556("invulnerable", false);
        abilities.method_10556("mayBuild", true);
        abilities.method_10556("instabuild", false);
        player.method_10566("abilities", abilities);

        class_2507.method_30614(player, new File(new File(worldFolder, "playerdata"), uuid + ".dat").toPath());
        System.out.println(" playerdata written for " + uuid);
    }

    private static void writeEmptyAdvancements(File worldFolder, class_310 client) throws IOException {
        if (client.field_1724 == null) return;
        String uuid = client.field_1724.method_5667().toString();
        Files.writeString(new File(new File(worldFolder, "advancements"), uuid + ".json").toPath(), "{}");
    }

    private static void writeEmptyStats(File worldFolder, class_310 client) throws IOException {
        if (client.field_1724 == null) return;
        int dataVersion = ChunkListener.getDataVersion();
        String uuid = client.field_1724.method_5667().toString();
        Files.writeString(
                new File(new File(worldFolder, "stats"), uuid + ".json").toPath(),
                "{\"stats\":{},\"DataVersion\":" + dataVersion + "}"
        );
    }

    /**
     * Scans from Y=320 downward to find a valid spawn position where:
     * - block at Y   is air (feet)
     * - block at Y+1 is air (head)
     * - block at Y-1 is solid (ground to stand on)
     */
    private static int findSafeSpawnY(class_638 world, int x, int z) {
        if (world == null) return 64;
        int maxY = 318; // 320 - 2 (Overworld max, Platz für feet+head check)
        for (int y = maxY; y > world.method_31607() + 1; y--) {
            class_2338 feet   = new class_2338(x, y,     z);
            class_2338 head   = new class_2338(x, y + 1, z);
            class_2338 ground = new class_2338(x, y - 1, z);

            boolean feetClear   = world.method_8320(feet).method_26220(world, feet).method_1110();
            boolean headClear   = world.method_8320(head).method_26220(world, head).method_1110();
            boolean groundSolid = !world.method_8320(ground).method_26220(world, ground).method_1110();

            if (feetClear && headClear && groundSolid) {
                return y;
            }
        }
        return 64;
    }
}
