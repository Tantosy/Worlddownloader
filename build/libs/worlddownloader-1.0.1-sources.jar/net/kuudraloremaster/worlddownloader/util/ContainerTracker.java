package net.kuudraloremaster.worlddownloader.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.config.ModConfig;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2745;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3917;
import net.minecraft.class_638;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public class ContainerTracker {

    // syncId -> ContainerData
    private static final Map<Integer, ContainerData> openContainers = new ConcurrentHashMap<>();
    // BlockPos -> saved NBT
    private static final Map<class_2338, class_2487> savedContainerData = new ConcurrentHashMap<>();

    public static void onContainerOpened(int syncId, class_3917<?> type) {
        System.out.println(" Container opened at syncId=" + syncId);
        openContainers.put(syncId, new ContainerData(syncId));
    }

    public static void setBlockPos(int syncId, class_2338 pos) {
        ContainerData data = openContainers.get(syncId);
        if (data != null) {
            data.blockPos = pos;
            System.out.println("[WD] Set blockPos for syncId=" + syncId + " to " + pos);
        }
    }

    public static void onContainerClosed(int syncId, class_638 world) {
        // Prüfen ob Container-Speichern aktiviert ist
        if (!ModConfig.getInstance().isSaveContainers()) {
            openContainers.remove(syncId);
            System.out.println(" Container closed - not saving (SaveContainers disabled)");
            return;
        }

        ContainerData data = openContainers.remove(syncId);
        if (data == null) return;

        if (world == null || data.blockPos == null) {
            System.out.println(" Container closed at syncId=" + syncId + " (no world/pos)");
            return;
        }

        System.out.println(" Container closed at " + data.blockPos);
        try {
            var blockState = world.method_8320(data.blockPos);
            class_2248 block = blockState.method_26204();

            if (block instanceof class_2281 || block instanceof net.minecraft.class_2531) {
                handleDoubleChest(world, data, blockState);
            } else {
                handleRegularContainer(data);
            }
        } catch (Exception e) {
            System.out.println(" Failed to handle double chest, falling back to regular container: " + e.getMessage());
            handleRegularContainer(data);
        }
    }

    private static void handleDoubleChest(class_638 world, ContainerData data,
                                           net.minecraft.class_2680 blockState) {
        try {
            class_2745 chestType = blockState.method_11654(class_2281.field_10770);
            class_2350 facing = blockState.method_11654(class_2281.field_10768);
            class_2350 adjacentDirection = (chestType == class_2745.field_12574)
                    ? facing.method_10170()
                    : facing.method_10160();

            if (chestType == class_2745.field_12569) {
                handleRegularContainer(data);
                return;
            }

            // RIGHT-Block bekommt immer Slots 0–26, LEFT-Block bekommt Slots 27–53
            class_2338 rightPos, leftPos;
            if (chestType == class_2745.field_12571) {
                rightPos = data.blockPos;
                leftPos = data.blockPos.method_10093(adjacentDirection);
            } else {
                leftPos = data.blockPos;
                rightPos = data.blockPos.method_10093(adjacentDirection);
            }

            List<class_1799> rightItems = data.getItemsRange(0, 27);
            List<class_1799> leftItems = data.getItemsRange(27, 54);

            class_2487 rightNbt = buildChestNbt(rightPos, rightItems, class_2745.field_12571, facing);
            class_2487 leftNbt = buildChestNbt(leftPos, leftItems, class_2745.field_12574, facing);

            savedContainerData.put(rightPos, rightNbt);
            savedContainerData.put(leftPos, leftNbt);

            long rightNonEmpty = rightItems.stream().filter(s -> !s.method_7960()).count();
            long leftNonEmpty = leftItems.stream().filter(s -> !s.method_7960()).count();
            System.out.println(" Saved double chest:");
            System.out.println("    - Right chest at " + rightPos + " with " + rightNonEmpty + " filled slots");
            System.out.println("    - Left chest at " + leftPos + " with " + leftNonEmpty + " filled slots");

            resaveChunkForPos(rightPos);
            resaveChunkForPos(leftPos);
        } catch (Exception e) {
            System.out.println(" Failed to handle double chest, falling back to regular container: " + e.getMessage());
            handleRegularContainer(data);
        }
    }

    private static void handleRegularContainer(ContainerData data) {
        if (data.blockPos == null) return;
        class_2487 nbt = data.toNbt();
        if (nbt != null) {
            savedContainerData.put(data.blockPos, nbt);
            long nonEmpty = data.getAllItems().stream().filter(s -> !s.method_7960()).count();
            System.out.println(" Saved regular container at " + data.blockPos + " with " + nonEmpty + " filled slots");
            resaveChunkForPos(data.blockPos);
        }
    }

    /**
     * Serialisiert den Chunk neu und aktualisiert den ChunkListener-Cache.
     * Nötig weil der Cache beim ersten Chunk-Load befüllt wurde — vor dem Container-Open.
     * ClientChunkSerializer.serialize() ruft enhanceBlockEntityWithContainerData() auf,
     * sodass der neue Cache-Eintrag die Kisten-Items enthält.
     */
    private static void resaveChunkForPos(class_2338 pos) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;
        class_1923 chunkPos = new class_1923(pos);
        class_2818 chunk = mc.field_1687.method_8497(chunkPos.field_9181, chunkPos.field_9180);
        class_2487 nbt = ClientChunkSerializer.serialize(mc.field_1687, chunk);
        ChunkListener.addChunkNbt(chunkPos, nbt);
        System.out.println("[WD] Re-serialized chunk " + chunkPos + " after container close");
    }

    private static class_2487 buildChestNbt(class_2338 pos, List<class_1799> items,
                                              class_2745 chestType, class_2350 facing) {
        class_2487 nbt = new class_2487();
        var mc = class_310.method_1551();
        var blockEntity = mc.field_1687 != null ? mc.field_1687.method_8321(pos) : null;
        String id = blockEntity != null
                ? net.minecraft.class_7923.field_41181.method_10221(blockEntity.method_11017()).toString()
                : "minecraft:chest";
        nbt.method_10582("id", id);
        nbt.method_10569("x", pos.method_10263());
        nbt.method_10569("y", pos.method_10264());
        nbt.method_10569("z", pos.method_10260());
        nbt.method_10556("keepPacked", false);

        var lookup = mc.field_1687 != null ? mc.field_1687.method_30349() : null;

        class_2499 itemsList = new class_2499();
        for (int i = 0; i < items.size(); i++) {
            class_1799 stack = items.get(i);
            if (!stack.method_7960() && lookup != null) {
                final byte slotByte = (byte) i;
                var result = class_1799.field_24671.encodeStart(lookup.method_57093(class_2509.field_11560), stack).result();
                result.ifPresent(el -> {
                    class_2487 itemNbt = (class_2487) el;
                    itemNbt.method_10567("Slot", slotByte);
                    itemsList.add(itemNbt);
                });
            }
        }
        nbt.method_10566("Items", itemsList);
        return nbt;
    }

    public static void onInventoryUpdate(int syncId, List<class_1799> stacks) {
        ContainerData data = openContainers.get(syncId);
        if (data == null) return;
        data.setInventory(stacks);
        if (data.blockPos != null) {
            class_2487 nbt = data.toNbt();
            if (nbt != null) savedContainerData.put(data.blockPos, nbt);
        }
    }

    public static void onSlotUpdate(int syncId, int slot, class_1799 stack) {
        ContainerData data = openContainers.get(syncId);
        if (data == null) return;
        data.updateSlot(slot, stack);
    }

    public static boolean hasContainerData(class_2338 pos) {
        return savedContainerData.containsKey(pos);
    }

    public static class_2487 getContainerData(class_2338 pos) {
        return savedContainerData.get(pos);
    }

    public static class_2487 enhanceBlockEntityWithContainerData(class_2338 pos, class_2487 original) {
        class_2487 saved = savedContainerData.get(pos);
        if (saved == null) return original;

        class_2487 enhanced = original.method_10553();
        if (saved.method_10545("Items")) {
            enhanced.method_10566("Items", saved.method_10580("Items"));
        }
        System.out.println(" Enhanced block entity at " + pos);
        return enhanced;
    }

    public static int getTotalSavedContainers() {
        return savedContainerData.size();
    }

    public static void clear() {
        openContainers.clear();
        savedContainerData.clear();
        System.out.println(" Cleared all container data");
    }

    // -------------------------------------------------------------------------

    public static class ContainerData {
        private final int syncId;
        public class_2338 blockPos;
        private final Map<Integer, class_1799> containerSlots = new ConcurrentHashMap<>();

        public ContainerData(int syncId) {
            this.syncId = syncId;
        }

        public void setInventory(List<class_1799> stacks) {
            for (int i = 0; i < stacks.size(); i++) {
                containerSlots.put(i, stacks.get(i).method_7972());
            }
        }

        public void updateSlot(int slot, class_1799 stack) {
            containerSlots.put(slot, stack.method_7972());
        }

        public int getSlotCount() {
            return containerSlots.isEmpty() ? 0 : containerSlots.keySet().stream().max(Integer::compare).orElse(0) + 1;
        }

        public List<class_1799> getAllItems() {
            int max = getSlotCount();
            return java.util.stream.IntStream.range(0, max)
                    .mapToObj(i -> containerSlots.getOrDefault(i, class_1799.field_8037))
                    .toList();
        }

        public List<class_1799> getItemsRange(int from, int to) {
            return java.util.stream.IntStream.range(from, to)
                    .mapToObj(i -> containerSlots.getOrDefault(i, class_1799.field_8037))
                    .toList();
        }

        public class_2487 toNbt() {
            if (blockPos == null) return null;
            var mc = class_310.method_1551();
            if (mc.field_1687 == null) return null;
            var lookup = mc.field_1687.method_30349();

            var blockEntity = mc.field_1687.method_8321(blockPos);
            String id = blockEntity != null
                    ? net.minecraft.class_7923.field_41181.method_10221(blockEntity.method_11017()).toString()
                    : "minecraft:chest";

            class_2487 nbt = new class_2487();
            nbt.method_10582("id", id);
            nbt.method_10569("x", blockPos.method_10263());
            nbt.method_10569("y", blockPos.method_10264());
            nbt.method_10569("z", blockPos.method_10260());
            nbt.method_10556("keepPacked", false);

            class_2499 itemsList = new class_2499();
            containerSlots.forEach((slot, stack) -> {
                if (!stack.method_7960()) {
                    var result = class_1799.field_24671.encodeStart(lookup.method_57093(class_2509.field_11560), stack).result();
                    result.ifPresent(el -> {
                        class_2487 itemNbt = (class_2487) el;
                        itemNbt.method_10567("Slot", (byte) (int) slot);
                        itemsList.add(itemNbt);
                    });
                }
            });
            nbt.method_10566("Items", itemsList);
            return nbt;
        }
    }
}
