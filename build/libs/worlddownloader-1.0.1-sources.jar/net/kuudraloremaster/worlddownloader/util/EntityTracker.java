package net.kuudraloremaster.worlddownloader.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2494;
import net.minecraft.class_2499;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public class EntityTracker {

    private static final Map<class_1923, List<class_2487>> entities = new ConcurrentHashMap<>();

    public static void captureAllEntities(class_310 client) {
        if (client.field_1687 == null) {
            System.out.println(" ClientWorld is null, cannot capture entities");
            return;
        }

        entities.clear();
        int totalEntities = 0;

        System.out.println(" Starting entity capture...");
        for (class_1297 entity : client.field_1687.method_18112()) {
            try {
                class_2487 entityNbt = serializeEntity(entity, client);
                if (entityNbt == null) continue;

                class_1923 chunkPos = new class_1923(
                        class_3532.method_15357(entity.method_23317()) >> 4,
                        class_3532.method_15357(entity.method_23321()) >> 4
                );

                entities.computeIfAbsent(chunkPos, k -> new ArrayList<>()).add(entityNbt);
                totalEntities++;
            } catch (Exception e) {
                System.out.println(" Failed to serialize entity " + entity + ": " + e.getMessage());
            }
        }

        System.out.println(" Captured " + totalEntities + " entities across " + entities.size() + " chunks");
    }

    private static class_2487 serializeEntity(class_1297 entity, class_310 client) {
        var entityTypeId = class_7923.field_41177.method_10221(entity.method_5864());
        if (entityTypeId == null) return null;

        class_2487 nbt = new class_2487();
        nbt.method_10582("id", entityTypeId.toString());

        // Position
        class_2499 posNbt = new class_2499();
        posNbt.add(class_2489.method_23241(entity.method_23317()));
        posNbt.add(class_2489.method_23241(entity.method_23318()));
        posNbt.add(class_2489.method_23241(entity.method_23321()));
        nbt.method_10566("Pos", posNbt);

        // Motion
        class_2499 motionNbt = new class_2499();
        motionNbt.add(class_2489.method_23241(entity.method_18798().field_1352));
        motionNbt.add(class_2489.method_23241(entity.method_18798().field_1351));
        motionNbt.add(class_2489.method_23241(entity.method_18798().field_1350));
        nbt.method_10566("Motion", motionNbt);

        // Rotation
        class_2499 rotationNbt = new class_2499();
        rotationNbt.add(class_2494.method_23244(entity.method_36454()));
        rotationNbt.add(class_2494.method_23244(entity.method_36455()));
        nbt.method_10566("Rotation", rotationNbt);

        // UUID
        nbt.method_10539("UUID", new int[]{
                (int)(entity.method_5667().getMostSignificantBits() >> 32),
                (int) entity.method_5667().getMostSignificantBits(),
                (int)(entity.method_5667().getLeastSignificantBits() >> 32),
                (int) entity.method_5667().getLeastSignificantBits()
        });

        // Common flags
        nbt.method_10556("OnGround", entity.method_24828());
        nbt.method_10556("Invulnerable", entity.method_5655());
        nbt.method_10569("PortalCooldown", entity.method_51848());
        nbt.method_10556("NoGravity", entity.method_5740());
        nbt.method_10556("Glowing", entity.method_5851());
        nbt.method_10556("Silent", entity.method_5701());

        // Custom name
        if (entity.method_16914() && entity.method_5797() != null) {
            String customNameJson = net.minecraft.class_8824.field_46597
                    .encodeStart(
                            net.minecraft.class_6903.method_46632(
                                    com.mojang.serialization.JsonOps.INSTANCE,
                                    client.field_1687.method_30349()),
                            entity.method_5797())
                    .result()
                    .map(e -> e.toString())
                    .orElse("\"\"");
            nbt.method_10582("CustomName", customNameJson);
            nbt.method_10556("CustomNameVisible", entity.method_5807());
        }

        // Living entity data
        if (entity instanceof class_1309 living) {
            addLivingEntityData(nbt, living, client);
        }

        // ItemEntity data
        if (entity instanceof class_1542 itemEntity) {
            addItemEntityData(nbt, itemEntity, client);
        }

        return nbt;
    }

    private static void addLivingEntityData(class_2487 nbt, class_1309 living,
                                             class_310 client) {
        nbt.method_10548("Health", living.method_6032());
        nbt.method_10548("AbsorptionAmount", living.method_6067());
        nbt.method_10575("HurtTime", (short) living.field_6235);
        nbt.method_10575("DeathTime", (short) living.field_6213);
        nbt.method_10548("HurtByTimestamp", 0);
        nbt.method_10556("Invulnerable", living.method_5655());

        // Hand and armor items
        class_2499 handItems = new class_2499();
        for (var stack : List.of(living.method_6047(), living.method_6079())) {
            class_2487 itemNbt = new class_2487();
            itemNbt.method_10582("id", class_7923.field_41178.method_10221(stack.method_7909()).toString());
            itemNbt.method_10567("Count", (byte) stack.method_7947());
            handItems.add(itemNbt);
        }
        nbt.method_10566("HandItems", handItems);

        class_2499 armorItems = new class_2499();
        for (var slot : List.of(net.minecraft.class_1304.field_6166, net.minecraft.class_1304.field_6172,
                net.minecraft.class_1304.field_6174, net.minecraft.class_1304.field_6169)) {
            var stack = living.method_6118(slot);
            class_2487 itemNbt = new class_2487();
            itemNbt.method_10582("id", class_7923.field_41178.method_10221(stack.method_7909()).toString());
            itemNbt.method_10567("Count", (byte) stack.method_7947());
            armorItems.add(itemNbt);
        }
        nbt.method_10566("ArmorItems", armorItems);

        class_2499 handDropChances = new class_2499();
        handDropChances.add(class_2494.method_23244(0.085f));
        handDropChances.add(class_2494.method_23244(0.085f));
        nbt.method_10566("HandDropChances", handDropChances);

        class_2499 armorDropChances = new class_2499();
        for (int i = 0; i < 4; i++) armorDropChances.add(class_2494.method_23244(0.085f));
        nbt.method_10566("ArmorDropChances", armorDropChances);

        // Mob data
        if (living instanceof class_1308 mob) {
            nbt.method_10556("PersistenceRequired", mob.method_5947());
            nbt.method_10556("LeftHanded", mob.method_5961());
            nbt.method_10556("CanPickUpLoot", mob.method_5936());
        }

        // Animal data
        if (living instanceof class_1429 animal) {
            nbt.method_10569("InLove", animal.method_29270());
            nbt.method_10569("Age", animal.method_5618());
            if (animal.method_6478() != null) {
                nbt.method_10539("LoveCause", new int[]{
                        (int)(animal.method_6478().method_5667().getMostSignificantBits() >> 32),
                        (int) animal.method_6478().method_5667().getMostSignificantBits(),
                        (int)(animal.method_6478().method_5667().getLeastSignificantBits() >> 32),
                        (int) animal.method_6478().method_5667().getLeastSignificantBits()
                });
            }
        }
    }

    private static void addItemEntityData(class_2487 nbt, class_1542 itemEntity,
                                           class_310 client) {
        var stack = itemEntity.method_6983();
        class_2487 itemNbt = new class_2487();
        itemNbt.method_10582("id", class_7923.field_41178.method_10221(stack.method_7909()).toString());
        itemNbt.method_10567("Count", (byte) stack.method_7947());
        nbt.method_10566("Item", itemNbt);
        nbt.method_10575("PickupDelay", (short) 10);
    }

    public static Map<class_1923, List<class_2487>> getAll() {
        return entities;
    }

    public static List<class_2487> getEntitiesForChunk(class_1923 chunkPos) {
        List<class_2487> result = entities.getOrDefault(chunkPos, new ArrayList<>());
        System.out.println(" Retrieved " + result.size() + " entities for chunk " + chunkPos.field_9181 + "," + chunkPos.field_9180);
        return result;
    }

    public static int getTotalTrackedEntities() {
        return entities.values().stream().mapToInt(List::size).sum();
    }

    public static void clear() {
        int count = getTotalTrackedEntities();
        entities.clear();
        System.out.println(" Cleared " + count + " tracked entities");
    }
}
