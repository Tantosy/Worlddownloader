package net.kuudraloremaster.worlddownloader.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2902;
import net.minecraft.class_638;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class ClientChunkSerializer {

    public static class_2487 serialize(class_638 world, class_2818 chunk) {
        class_2487 chunkNbt = new class_2487();
        class_1923 chunkPos = chunk.method_12004();

        chunkNbt.method_10569("DataVersion", 4671);
        chunkNbt.method_10569("xPos", chunkPos.field_9181);
        chunkNbt.method_10569("zPos", chunkPos.field_9180);
        chunkNbt.method_10569("yPos", chunk.method_32891());
        chunkNbt.method_10582("Status", "minecraft:full");
        chunkNbt.method_10544("LastUpdate", System.currentTimeMillis());
        chunkNbt.method_10544("InhabitedTime", 0L);

        // Sections
        class_2499 sectionsNbt = new class_2499();
        class_2826[] sections = chunk.method_12006();
        int minY = chunk.method_32891();

        for (int i = 0; i < sections.length; i++) {
            class_2826 section = sections[i];
            class_2487 sectionNbt = new class_2487();
            sectionNbt.method_10567("Y", (byte)(minY + i));

            if (section != null && !section.method_38292()) {
                sectionNbt.method_10566("block_states", serializeBlockStates(section));
                sectionNbt.method_10566("biomes", serializeBiomes(section));
            }
            sectionsNbt.add(sectionNbt);
        }
        chunkNbt.method_10566("sections", sectionsNbt);

        // Heightmaps
        class_2487 heightmapsNbt = new class_2487();
        for (Map.Entry<class_2902.class_2903, class_2902> entry : chunk.method_12011()) {
            if (entry.getKey().method_20454()) {
                heightmapsNbt.method_10564(entry.getKey().method_15434(), entry.getValue().method_12598());
            }
        }
        chunkNbt.method_10566("Heightmaps", heightmapsNbt);

        // Block entities
        class_2499 blockEntitiesNbt = new class_2499();
        for (Map.Entry<class_2338, class_2586> entry : chunk.method_12214().entrySet()) {
            class_2338 pos = entry.getKey();
            class_2586 be = entry.getValue();
            try {
                class_2487 beNbt = be.method_38244(world.method_30349());
                beNbt = ContainerTracker.enhanceBlockEntityWithContainerData(pos, beNbt);
                beNbt.method_10556("keepPacked", false);
                blockEntitiesNbt.add(beNbt);
            } catch (Exception e) {
                System.out.println("[WD] Failed to serialize block entity at " + pos + ": " + e.getMessage());
            }
        }
        chunkNbt.method_10566("block_entities", blockEntitiesNbt);

        // Empty structures
        class_2487 structuresNbt = new class_2487();
        structuresNbt.method_10566("starts", new class_2487());
        structuresNbt.method_10566("References", new class_2487());
        chunkNbt.method_10566("structures", structuresNbt);

        return chunkNbt;
    }

    private static class_2487 serializeBlockStates(class_2826 section) {
        class_2487 blockStatesNbt = new class_2487();
        var container = section.method_12265();

        List<class_2680> palette = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();

        for (int y = 0; y < 16; y++) {
            for (int z = 0; z < 16; z++) {
                for (int x = 0; x < 16; x++) {
                    class_2680 state = container.method_12321(x, y, z);
                    int idx = palette.indexOf(state);
                    if (idx == -1) { idx = palette.size(); palette.add(state); }
                    indices.add(idx);
                }
            }
        }

        class_2499 paletteNbt = new class_2499();
        for (class_2680 state : palette) {
            class_2487 stateNbt = new class_2487();
            stateNbt.method_10582("Name", class_7923.field_41175.method_10221(state.method_26204()).toString());
            if (!state.method_11656().isEmpty()) {
                class_2487 props = new class_2487();
                state.method_11656().forEach((prop, val) ->
                    props.method_10582(prop.method_11899(), val.toString()));
                stateNbt.method_10566("Properties", props);
            }
            paletteNbt.add(stateNbt);
        }
        blockStatesNbt.method_10566("palette", paletteNbt);

        if (palette.size() > 1) {
            blockStatesNbt.method_10564("data", pack(indices, palette.size()));
        }
        return blockStatesNbt;
    }

    private static class_2487 serializeBiomes(class_2826 section) {
        class_2487 biomesNbt = new class_2487();
        var biomeContainer = section.method_38294();

        List<String> biomeIds = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();

        for (int y = 0; y < 4; y++) {
            for (int z = 0; z < 4; z++) {
                for (int x = 0; x < 4; x++) {
                    var entry = biomeContainer.method_12321(x, y, z);
                    String id = entry.method_40230()
                        .map(k -> k.method_29177().toString())
                        .orElse("minecraft:plains");
                    int idx = biomeIds.indexOf(id);
                    if (idx == -1) { idx = biomeIds.size(); biomeIds.add(id); }
                    indices.add(idx);
                }
            }
        }

        class_2499 palNbt = new class_2499();
        for (String id : biomeIds) palNbt.add(class_2519.method_23256(id));
        biomesNbt.method_10566("palette", palNbt);
        if (biomeIds.size() > 1) biomesNbt.method_10564("data", pack(indices, biomeIds.size(), 1));
        return biomesNbt;
    }

    private static long[] pack(List<Integer> values, int paletteSize) {
        return pack(values, paletteSize, 4);
    }

    private static long[] pack(List<Integer> values, int paletteSize, int minBits) {
        int bits = Math.max(minBits, 32 - Integer.numberOfLeadingZeros(paletteSize - 1));
        int perLong = 64 / bits;
        long[] data = new long[(values.size() + perLong - 1) / perLong];
        for (int i = 0; i < values.size(); i++) {
            data[i / perLong] |= ((long) values.get(i)) << ((i % perLong) * bits);
        }
        return data;
    }
}
