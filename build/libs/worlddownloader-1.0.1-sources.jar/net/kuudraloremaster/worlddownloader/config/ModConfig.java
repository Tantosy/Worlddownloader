package net.kuudraloremaster.worlddownloader.config;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

/**
 * Configuration class for World Downloader settings.
 * Settings are persisted to .minecraft/worlddownloader_config.nbt
 */
public class ModConfig {

    private static final String CONFIG_FILE_NAME = "worlddownloader_config.nbt";

    // General Settings
    private boolean autoExportServer = false;
    private boolean autoExportSingleplayer = true;
    private boolean autoStartServer = false;
    private boolean autoStartSingleplayer = false;

    // Export Settings
    private boolean exportWithTexturePack = true;
    private boolean saveContainers = false;

    private static ModConfig instance;

    private ModConfig() {
        load();
    }

    public static ModConfig getInstance() {
        if (instance == null) {
            instance = new ModConfig();
        }
        return instance;
    }

    // General Settings Getters/Setters
    public boolean isAutoExportServer() {
        return autoExportServer;
    }

    public void setAutoExportServer(boolean autoExportServer) {
        this.autoExportServer = autoExportServer;
        save();
    }

    public boolean isAutoExportSingleplayer() {
        return autoExportSingleplayer;
    }

    public void setAutoExportSingleplayer(boolean autoExportSingleplayer) {
        this.autoExportSingleplayer = autoExportSingleplayer;
        save();
    }

    // Export Settings Getters/Setters
    public boolean isExportWithTexturePack() {
        return exportWithTexturePack;
    }

    public void setExportWithTexturePack(boolean exportWithTexturePack) {
        this.exportWithTexturePack = exportWithTexturePack;
        save();
    }

    public boolean isSaveContainers() {
        return saveContainers;
    }

    public void setSaveContainers(boolean saveContainers) {
        this.saveContainers = saveContainers;
        save();
    }

    // Auto Start Settings Getters/Setters
    public boolean isAutoStartServer() {
        return autoStartServer;
    }

    public void setAutoStartServer(boolean autoStartServer) {
        this.autoStartServer = autoStartServer;
        save();
    }

    public boolean isAutoStartSingleplayer() {
        return autoStartSingleplayer;
    }

    public void setAutoStartSingleplayer(boolean autoStartSingleplayer) {
        this.autoStartSingleplayer = autoStartSingleplayer;
        save();
    }

    private Path getConfigPath() {
        return FabricLoader.getInstance().getGameDir().resolve(CONFIG_FILE_NAME);
    }

    public void save() {
        class_2487 nbt = new class_2487();
        nbt.method_10556("AutoExportServer", autoExportServer);
        nbt.method_10556("AutoExportSingleplayer", autoExportSingleplayer);
        nbt.method_10556("AutoStartServer", autoStartServer);
        nbt.method_10556("AutoStartSingleplayer", autoStartSingleplayer);
        nbt.method_10556("ExportWithTexturePack", exportWithTexturePack);
        nbt.method_10556("SaveContainers", saveContainers);

        try {
            class_2507.method_30614(nbt, getConfigPath());
        } catch (IOException e) {
            System.out.println("[WorldDownloader] Failed to save config: " + e.getMessage());
        }
    }

    public void load() {
        File configFile = getConfigPath().toFile();
        if (!configFile.exists()) {
            return;
        }

        try {
            class_2487 nbt = class_2507.method_30613(configFile.toPath(), net.minecraft.class_2505.method_53898());
            if (nbt == null) {
                return;
            }

            // Migrate old AutoExport to AutoExportServer
            if (nbt.method_10545("AutoExport")) {
                autoExportServer = nbt.method_10577("AutoExport").orElse(false);
            } else if (nbt.method_10545("AutoExportServer")) {
                autoExportServer = nbt.method_10577("AutoExportServer").orElse(false);
            }
            if (nbt.method_10545("AutoExportSingleplayer")) {
                autoExportSingleplayer = nbt.method_10577("AutoExportSingleplayer").orElse(true);
            }
            if (nbt.method_10545("ExportWithTexturePack")) {
                exportWithTexturePack = nbt.method_10577("ExportWithTexturePack").orElse(true);
            }
            if (nbt.method_10545("SaveContainers")) {
                saveContainers = nbt.method_10577("SaveContainers").orElse(false);
            }
            if (nbt.method_10545("AutoStartServer")) {
                autoStartServer = nbt.method_10577("AutoStartServer").orElse(false);
            }
            if (nbt.method_10545("AutoStartSingleplayer")) {
                autoStartSingleplayer = nbt.method_10577("AutoStartSingleplayer").orElse(false);
            }
        } catch (IOException e) {
            System.out.println("[WorldDownloader] Failed to load config: " + e.getMessage());
        }
    }

    public void resetToDefaults() {
        autoExportServer = false;
        autoExportSingleplayer = true;
        autoStartServer = false;
        autoStartSingleplayer = false;
        exportWithTexturePack = true;
        saveContainers = false;
        save();
    }
}
