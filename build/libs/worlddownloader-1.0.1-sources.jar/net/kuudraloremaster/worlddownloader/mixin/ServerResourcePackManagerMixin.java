package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.WorldDownloaderClient;
import net.minecraft.class_9028;
import net.minecraft.class_9044;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;
import java.util.Collection;
import java.util.Map;

/**
 * Hook for saving server resource pack location when downloaded.
 */
@Environment(EnvType.CLIENT)
@Mixin(class_9044.class)
public abstract class ServerResourcePackManagerMixin {

    @Inject(method = "onDownload", at = @At("TAIL"))
    private void onDownload(Collection<?> packs, class_9028.class_9030 result, CallbackInfo ci) {
        System.out.println(" [WorldDownloader] Resource pack download completed");

        // Get the downloaded packs map (UUID -> Path)
        Map<?, ?> downloaded = result.comp_2143();

        if (downloaded != null && !downloaded.isEmpty()) {
            // Get the first downloaded pack path
            for (Map.Entry<?, ?> entry : downloaded.entrySet()) {
                Object value = entry.getValue();
                if (value instanceof Path) {
                    Path packPath = (Path) value;
                    WorldDownloaderClient.resourcePackLocation = packPath;
                    System.out.println(" [WorldDownloader] Resource pack location saved: " + packPath);
                    break; // Only need the first one
                }
            }
        }
    }
}
