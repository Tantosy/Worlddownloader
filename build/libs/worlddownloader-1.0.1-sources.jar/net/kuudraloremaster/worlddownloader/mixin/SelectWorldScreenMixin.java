package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.WorldFolderManager;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_526;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

@Environment(EnvType.CLIENT)
@Mixin(class_526.class)
public abstract class SelectWorldScreenMixin extends class_437 {

    protected SelectWorldScreenMixin() {
        super(null, null, class_2561.method_43473());
    }

    @Inject(method = "init", at = @At("HEAD"))
    private void onInitHead(CallbackInfo ci) {
        this.field_22785 = WorldFolderManager.isDownloadedWorldsActive()
                ? class_2561.method_43470("Downloaded Worlds")
                : class_2561.method_43470("Normal Worlds");
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void addDownloadedWorldsButton(CallbackInfo ci) {
        boolean active = WorldFolderManager.isDownloadedWorldsActive();
        boolean hasDownloaded = WorldFolderManager.hasDownloadedWorlds(this.field_22787);

        class_2561 label = active
                ? class_2561.method_43471("worlddownloader.gui.normal_worlds")
                : class_2561.method_43471("worlddownloader.gui.downloaded_worlds");

        class_4185 button = class_4185.method_46430(label, btn -> {
            WorldFolderManager.toggle(this.field_22787);
            this.field_22787.method_1507(new class_526(null));
        }).method_46434(this.field_22789 / 2 + 156, this.field_22790 - 52, 150, 20).method_46431();

        if (!active && !hasDownloaded) {
            button.field_22763 = false;
        }

        this.method_37063(button);
    }
}
