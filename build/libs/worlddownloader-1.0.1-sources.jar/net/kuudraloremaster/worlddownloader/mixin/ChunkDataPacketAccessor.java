package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2672;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin(class_2672.class)
public interface ChunkDataPacketAccessor {
    @Accessor("chunkX")
    int getChunkX();

    @Accessor("chunkZ")
    int getChunkZ();
}
