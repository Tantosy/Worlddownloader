package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.ChunkListener;
import net.kuudraloremaster.worlddownloader.util.ClientChunkSerializer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Serialisiert den Chunk neu wenn der Spieler einen Block abbaut oder platziert.
 * Für interactBlock: nur wenn sich die Nachbar-Position wirklich verändert hat
 * (= echter Block-Platzierungsfall). Türen, Hebel, Kisten etc. werden herausgefiltert.
 */
@Environment(EnvType.CLIENT)
@Mixin(class_636.class)
public class BlockInteractionMixin {

    @Unique
    private class_2680 wdAdjacentStateBefore;

    // Block abbauen — immer re-serialisieren
    @Inject(method = "breakBlock", at = @At("TAIL"))
    private void onBreakBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        resaveChunk(pos);
    }

    // Block-State an der Platzierungs-Position VOR der Interaktion merken
    @Inject(method = "interactBlock", at = @At("HEAD"))
    private void captureAdjacentBefore(class_746 player, class_1268 hand, class_3965 hitResult,
            CallbackInfoReturnable<class_1269> cir) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            wdAdjacentStateBefore = null;
            return;
        }
        class_2338 adjacentPos = hitResult.method_17777().method_10093(hitResult.method_17780());
        wdAdjacentStateBefore = client.field_1687.method_8320(adjacentPos);
    }

    // Nach der Interaktion: nur re-serialisieren wenn sich die Nachbar-Position geändert hat
    @Inject(method = "interactBlock", at = @At("TAIL"))
    private void onInteractBlock(class_746 player, class_1268 hand, class_3965 hitResult,
            CallbackInfoReturnable<class_1269> cir) {
        if (wdAdjacentStateBefore == null) return;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;

        class_2338 adjacentPos = hitResult.method_17777().method_10093(hitResult.method_17780());
        class_2680 adjacentAfter = client.field_1687.method_8320(adjacentPos);

        // Nur bei echtem Block-Platzierungsfall (Nachbar-State hat sich geändert)
        if (adjacentAfter != wdAdjacentStateBefore) {
            resaveChunk(adjacentPos);
        }
        wdAdjacentStateBefore = null;
    }

    private static void resaveChunk(class_2338 blockPos) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;

        class_1923 chunkPos = new class_1923(blockPos);
        class_2818 chunk = client.field_1687.method_8497(chunkPos.field_9181, chunkPos.field_9180);
        if (chunk == null) return;

        try {
            class_2487 nbt = ClientChunkSerializer.serialize(client.field_1687, chunk);
            ChunkListener.addChunkNbt(chunkPos, nbt);
        } catch (Exception e) {
            System.out.println("[WD] Failed to resave chunk after block placement at " + blockPos + ": " + e.getMessage());
        }
    }
}
