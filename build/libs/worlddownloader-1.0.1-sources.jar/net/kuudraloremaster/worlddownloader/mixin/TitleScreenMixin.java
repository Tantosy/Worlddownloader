package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.WorldFolderManager;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {

    protected TitleScreenMixin() {
        super(class_2561.method_43473());
    }

    @Inject(method = "init", at = @At("HEAD"))
    private void onTitleScreenInit(CallbackInfo ci) {
        if (WorldFolderManager.isDownloadedWorldsActive()) {
            WorldFolderManager.toggle(this.field_22787);
        }
    }
}
