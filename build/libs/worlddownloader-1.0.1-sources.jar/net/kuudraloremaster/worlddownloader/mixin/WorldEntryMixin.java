package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.WorldFolderManager;
import net.minecraft.class_310;
import net.minecraft.class_34;
import net.minecraft.class_526;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

@Environment(EnvType.CLIENT)
@Mixin(targets = "net.minecraft.client.gui.screen.world.WorldListWidget$WorldEntry")
public class WorldEntryMixin {

    @Shadow private class_34 level;

    @Inject(method = "recreate()V", at = @At("HEAD"), cancellable = true)
    private void interceptRecreateForDownloadedWorld(CallbackInfo ci) {
        if (!WorldFolderManager.isDownloadedWorldsActive()) return;

        // Standard-Re-Create (erzeugt Void-Welt) abbrechen und stattdessen Ordner kopieren
        ci.cancel();

        class_310 client = class_310.method_1551();
        Path savesDir = WorldFolderManager.getSavesDirectory(client);
        Path source = savesDir.resolve(level.method_248());
        String destName = findAvailableName(savesDir, level.method_248());
        Path dest = savesDir.resolve(destName);

        try {
            copyDirectory(source, dest);
        } catch (IOException e) {
            return;
        }

        client.method_1507(new class_526(null));
    }

    private static String findAvailableName(Path dir, String base) {
        if (!Files.exists(dir.resolve(base))) return base;
        int i = 2;
        while (Files.exists(dir.resolve(base + "_" + i))) i++;
        return base + "_" + i;
    }

    private static void copyDirectory(Path src, Path dest) throws IOException {
        try (Stream<Path> stream = Files.walk(src)) {
            for (Path path : (Iterable<Path>) stream::iterator) {
                Path target = dest.resolve(src.relativize(path));
                if (Files.isDirectory(path)) {
                    Files.createDirectories(target);
                } else {
                    Files.copy(path, target, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }
}
