package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.ContainerTracker;
import net.minecraft.class_1799;
import net.minecraft.class_2645;
import net.minecraft.class_2649;
import net.minecraft.class_2653;
import net.minecraft.class_3944;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Environment(EnvType.CLIENT)
@Mixin(class_634.class)
public class ContainerMixin {

    @Inject(method = "onOpenScreen", at = @At("TAIL"))
    private void onOpenScreen(class_3944 packet, CallbackInfo ci) {
        ContainerTracker.onContainerOpened(packet.method_17592(), packet.method_17593());
    }

    @Inject(method = "onCloseScreen", at = @At("TAIL"))
    private void onCloseScreen(class_2645 packet, CallbackInfo ci) {
        class_634 handler = (class_634) (Object) this;
        ContainerTracker.onContainerClosed(packet.method_36148(), handler.method_2890());
    }

    @Inject(method = "onInventory", at = @At("TAIL"))
    private void onInventory(class_2649 packet, CallbackInfo ci) {
        List<class_1799> stacks = packet.comp_3839();
        ContainerTracker.onInventoryUpdate(packet.comp_3837(), stacks);
    }

    @Inject(method = "onScreenHandlerSlotUpdate", at = @At("TAIL"))
    private void onScreenHandlerSlotUpdate(class_2653 packet, CallbackInfo ci) {
        ContainerTracker.onSlotUpdate(packet.method_11452(), packet.method_11450(), packet.method_11449());
    }
}
