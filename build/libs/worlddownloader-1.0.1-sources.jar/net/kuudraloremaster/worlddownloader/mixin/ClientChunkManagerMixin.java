package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.ChunkListener;
import net.kuudraloremaster.worlddownloader.util.ClientChunkSerializer;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_631;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.function.Consumer;

/**
 * Fängt loadChunkFromPacket ab — wird sowohl in Singleplayer als auch
 * Multiplayer aufgerufen wenn ein Chunk in die ClientWorld geladen wird.
 */
@Environment(EnvType.CLIENT)
@Mixin(class_631.class)
public class ClientChunkManagerMixin {

    @Inject(method = "loadChunkFromPacket", at = @At("RETURN"))
    private void onLoadChunkFromPacket(int x, int z, class_2540 buf,
            Map<class_2902.class_2903, long[]> heightmaps, Consumer<?> consumer,
            CallbackInfoReturnable<class_2818> cir) {
        class_2818 chunk = cir.getReturnValue();
        if (chunk == null) return;

        class_638 world = (class_638) chunk.method_12200();
        if (world == null) return;

        class_1923 pos = new class_1923(x, z);
        try {
            class_2487 nbt = ClientChunkSerializer.serialize(world, chunk);
            ChunkListener.addChunkNbt(pos, nbt);
        } catch (Exception e) {
            System.out.println("[WD] Failed to capture chunk " + x + "," + z + ": " + e.getMessage());
        }
    }
}
