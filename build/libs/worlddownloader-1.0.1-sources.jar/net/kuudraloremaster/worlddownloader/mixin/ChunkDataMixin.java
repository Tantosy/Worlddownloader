package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.WorldDownloaderClient;
import net.kuudraloremaster.worlddownloader.util.ChunkListener;
import net.kuudraloremaster.worlddownloader.util.ClientChunkSerializer;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_634.class)
public class ChunkDataMixin {

    @Inject(method = "onChunkData", at = @At("TAIL"))
    private void onChunkData(class_2672 packet, CallbackInfo ci) {
        if (!WorldDownloaderClient.isRecording()) return;

        class_634 handler = (class_634) (Object) this;
        var world = handler.method_2890();
        if (world == null) return;

        int chunkX = packet.method_11523();
        int chunkZ = packet.method_11524();
        class_1923 chunkPos = new class_1923(chunkX, chunkZ);

        class_2818 loadedChunk = world.method_8497(chunkX, chunkZ);
        if (loadedChunk == null) return;

        try {
            class_2487 chunkNbt = ClientChunkSerializer.serialize(world, loadedChunk);
            ChunkListener.addChunkNbt(chunkPos, chunkNbt);
        } catch (Exception e) {
            System.out.println("[WD] Failed to capture chunk " + chunkX + "," + chunkZ + ": " + e.getMessage());
        }
    }
}
