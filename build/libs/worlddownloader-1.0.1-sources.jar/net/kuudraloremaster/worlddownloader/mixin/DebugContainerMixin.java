package net.kuudraloremaster.worlddownloader.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.kuudraloremaster.worlddownloader.util.ContainerTracker;
import net.minecraft.class_1799;
import net.minecraft.class_2645;
import net.minecraft.class_2649;
import net.minecraft.class_2653;
import net.minecraft.class_310;
import net.minecraft.class_3944;
import net.minecraft.class_3965;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Environment(EnvType.CLIENT)
@Mixin(value = class_634.class, priority = 900)
public class DebugContainerMixin {

    @Inject(method = "onOpenScreen", at = @At("HEAD"))
    private void debugOnOpenScreen(class_3944 packet, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        String targetInfo = "unknown";
        if (client.field_1765 instanceof class_3965 blockHit) {
            var blockPos = blockHit.method_17777();
            var world = client.field_1687;
            if (world != null) {
                var block = world.method_8320(blockPos).method_26204();
                targetInfo = block.method_9518().getString() + " at " + blockPos;
            }
        }
        System.out.println(" DEBUG: OpenScreen packet - syncId: " + packet.method_17592() + " target: " + targetInfo);
    }

    @Inject(method = "onCloseScreen", at = @At("HEAD"))
    private void debugOnCloseScreen(class_2645 packet, CallbackInfo ci) {
        System.out.println(" DEBUG: CloseScreen packet - syncId: " + packet.method_36148());
    }

    @Inject(method = "onInventory", at = @At("HEAD"))
    private void debugOnInventory(class_2649 packet, CallbackInfo ci) {
        List<class_1799> stacks = packet.comp_3839();
        int totalSlots = stacks.size();
        long nonEmpty = stacks.stream().filter(s -> !s.method_7960()).count();

        class_310 client = class_310.method_1551();
        int playerSlots = (client.field_1724 != null) ? client.field_1724.method_31548().method_5439() : 0;
        int containerSlots = Math.max(0, Math.min(totalSlots, totalSlots - playerSlots));
        boolean playerNonEmpty = stacks.subList(containerSlots, totalSlots)
                .stream().anyMatch(s -> !s.method_7960());
        boolean containerNonEmpty = containerSlots > 0 && stacks.subList(0, containerSlots)
                .stream().anyMatch(s -> !s.method_7960());

        System.out.println(" DEBUG: Inventory packet - syncId: " + packet.comp_3837()
                + "    - Total slots: " + totalSlots
                + "    - Non-empty: " + nonEmpty
                + " (container + " + (playerNonEmpty ? "non-empty" : "empty") + " player)");

        // Print first 10 items in container portion
        System.out.println("      - Container items (first 10):");
        int limit = Math.min(10, containerSlots > 0 ? containerSlots : totalSlots);
        for (int i = 0; i < limit; i++) {
            class_1799 s = stacks.get(i);
            if (!s.method_7960()) {
                System.out.println("       [" + i + "] " + s.method_7909().method_63680().getString() + " x" + s.method_7947());
            }
        }
    }

    @Inject(method = "onScreenHandlerSlotUpdate", at = @At("HEAD"))
    private void debugOnSlotUpdate(class_2653 packet, CallbackInfo ci) {
        class_1799 stack = packet.method_11449();
        String itemInfo = stack.method_7960() ? "empty" : (stack.method_7909().method_63680().getString() + " x" + stack.method_7947());
        System.out.println(" DEBUG: SlotUpdate packet - syncId: " + packet.method_11452() + ", slot: " + packet.method_11450() + ", item: " + itemInfo);
    }
}
